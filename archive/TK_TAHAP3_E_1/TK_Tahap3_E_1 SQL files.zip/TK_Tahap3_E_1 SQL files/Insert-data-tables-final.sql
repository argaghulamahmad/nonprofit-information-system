INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('kyelyashev0@instagram.com', '4oBDdrwk', 'Kerry', '10 Truax Junction');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('mspeke1@squarespace.com', 'BE268Bgt', 'Merrill', '263 Reindahl Circle');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('hduham2@i2i.jp', 'MwjzjOr', 'Harriett', '545 Hayes Place');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('jprescote3@thetimes.co.uk', 'bMQmiXnnA0A', 'Jeremy', '005 Debs Parkway');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('smcdermott4@chronoengine.com', 'ZKhYTF7Ww5', 'Samuele', '2040 Bashford Place');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('jbrandin5@cnet.com', 'GdoqBJPo', 'Jemmie', '913 Di Loreto Way');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('fricciardo6@trellian.com', '4UnpslD0', 'Franklin', '57951 Upham Crossing');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('tmarshman7@bravesites.com', 'cMJx1npHGQ2P', 'Tadeo', '9016 Oak Valley Place');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('driping8@bloglines.com', 'COg6DIHzfc0A', 'Daffi', '9 Dwight Junction');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('rmccotter9@google.fr', 'X1LbWqe4pWx', 'Reider', '396 Center Lane');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('otrudgiana@scientificamerican.com', 'o2Sr8gR8jK', 'Oberon', '2090 Atwood Terrace');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ddilgarnob@upenn.edu', 'oklsirlzxg', 'Deidre', '769 Golf View Road');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('dmurrayc@live.com', '5RP4qZF', 'Daveta', '19 Westend Junction');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ahayd@nsw.gov.au', '1tN0b9BsFtn', 'Adela', '6 Cottonwood Lane');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('bolerenshawe@mtv.com', '8bvbLmRv4R2d', 'Bucky', '81 Bartillon Junction');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('fjeanequinf@blogtalkradio.com', 'ceyHPXvu', 'Feodor', '80160 Arapahoe Junction');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('qsinking@guardian.co.uk', 'SWOcWSG', 'Quintina', '05802 Rockefeller Center');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('lwaterfieldh@123-reg.co.uk', 'tU4YZefG', 'Laurena', '88409 Ramsey Center');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('cgilleasei@hc360.com', 'nGUIMw', 'Casar', '27140 Lawn Terrace');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('jtollj@wiley.com', 'RlwGBf2Srqq', 'Jone', '19814 Bartelt Lane');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('tbeak@toplist.cz', 'fDdzvGX4QJaZ', 'Teodoor', '8 Rigney Court');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('dgoldstrawl@a8.net', 'OKIIyur', 'Dulce', '255 Morning Plaza');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('rhaggathm@multiply.com', '7yslh0YfQCQ', 'Raquela', '8222 Mayer Trail');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('aturln@mit.edu', 'D9jtv9nB', 'Alexandrina', '91 Badeau Terrace');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ctanmano@walmart.com', 'l43IIo3Csj', 'Christi', '69203 Ronald Regan Alley');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('bharesnapep@youtube.com', 'n5nhVic702l', 'Beau', '4237 Hintze Circle');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('cstrewtherq@flavors.me', 'G7967AOig1k', 'Creighton', '7 Redwing Circle');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('saizkovitchr@harvard.edu', 'UHdE7nZ9', 'Siouxie', '62011 Manufacturers Crossing');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('sdevoielss@bizjournals.com', 'zaOkIANw5Le', 'Sherill', '692 Weeping Birch Junction');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('dklemket@netlog.com', 'qPpcELM', 'Dory', '66147 Cottonwood Pass');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('cgannicottu@paginegialle.it', 'U79glCy6Q', 'Calhoun', '8809 Utah Crossing');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('aromaynesv@yandex.ru', 'K7nWGe2e7zW', 'Archie', '302 Dawn Avenue');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('dkippingw@nih.gov', 'fEeYbpyon', 'Doug', '11138 Toban Circle');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ddagostinox@artisteer.com', 'WnpEpb', 'Dulcia', '5237 Westerfield Circle');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('fsutheringtony@jiathis.com', 'TfFwWMAuDL', 'Frayda', '1749 Darwin Circle');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('fwybrewz@google.cn', 'uilVOCGS', 'Farleigh', '2 Farwell Alley');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ceagan10@europa.eu', 'SA2Twc', 'Cilka', '2 Eastwood Way');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ashepley11@simplemachines.org', 'APCp98et', 'Ami', '967 Waubesa Lane');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('hbremley12@liveinternet.ru', '6PnPNETTux', 'Horatio', '903 Anhalt Avenue');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('cdietmar13@barnesandnoble.com', '7ATz8R9Y', 'Carole', '8949 Grayhawk Place');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('lsherwill14@yale.edu', 'DoDsNZDj', 'Lita', '4737 Park Meadow Road');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('fboteman15@rambler.ru', 'Oswict0pTjj', 'Fergus', '57412 Kim Pass');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('frichardeau16@soundcloud.com', 'dJ53iKsCO', 'Ferdinanda', '8252 Elgar Parkway');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('mdavinet17@photobucket.com', 'eyEKYgoYv', 'Milton', '98831 Pennsylvania Lane');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('akubes18@addtoany.com', 'hgrsSdjCY', 'Aubry', '9 Anthes Parkway');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('npavlovic19@e-recht24.de', 'PNTFBqU5cLxP', 'Niel', '20182 Garrison Circle');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('njewer1a@dot.gov', 'j9RzCndxvKgR', 'Nedda', '611 Parkside Street');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('igreenlees1b@livejournal.com', 'Lik0WKCfUh8', 'Ingar', '4 Gateway Road');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('sneubigging1c@yale.edu', '5bQ6xiwlK53I', 'Salomone', '7596 Bonner Pass');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('jfawson1d@jalbum.net', '809JHUoyvu', 'Jodie', '78 Acker Crossing');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('jantonoyev1e@chicagotribune.com', 'fAPBgwGX', 'Joyous', '97287 Morning Point');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('dgilmartin1f@creativecommons.org', 'FE1BzbrZG', 'Davis', '809 Scofield Circle');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('cmanolov1g@tamu.edu', 'xn0WmO', 'Corny', '2126 Crownhardt Terrace');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('jmosby1h@google.com.br', 'hXttD7xQ3z', 'Jamal', '6 Heath Avenue');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('mmacterrelly1i@state.gov', 'NviyLzy4Q', 'Moritz', '462 Mallard Junction');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ncloney1j@google.com.au', 'ZfefQevmz', 'Nananne', '595 Sunnyside Crossing');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('zhuton1k@admin.ch', 'rboyRUv', 'Zachery', '779 Starling Trail');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('phewins1l@weibo.com', 'R2bqzW', 'Pippy', '6925 Buell Park');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('llancley1m@sogou.com', 'z6NA3r', 'Lurline', '7226 Gina Point');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('pspatarul1n@gravatar.com', 'Xf8cyOOwV', 'Pacorro', '1 American Ash Road');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('hbim1o@paginegialle.it', 'uojTC1qKxnn', 'Holt', '85 Paget Center');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('vdincey1p@google.ca', 'Fzop7N', 'Vittorio', '44739 Lyons Court');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('bagar1q@angelfire.com', 'i1lu3BvW', 'Bank', '664 Vahlen Lane');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('jwhoolehan1r@dot.gov', 'zLpIJKh58Y', 'Jenny', '74 Toban Circle');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('wwoodes1s@nba.com', 'MpEXYzED', 'Whitman', '7 Schmedeman Drive');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('dveneur1t@huffingtonpost.com', '01vfsxla', 'Dawna', '4 Fulton Parkway');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('mportigall1u@china.com.cn', 'cohJtSuATGT3', 'Madella', '727 Maple Hill');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('kkiehne1v@amazon.com', 'dNEvJ2WKe', 'Kaia', '3816 Farmco Way');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('sheister1w@technorati.com', 'p8QIoNT7', 'Susann', '6 Sachs Drive');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('fgooders1x@theglobeandmail.com', 'DGKQZC7r', 'Finley', '47972 Comanche Circle');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('rsellan1y@parallels.com', 'R2Xx5sebMW', 'Roderic', '715 Grim Center');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('fleyes1z@godaddy.com', 'WWyDgtiMpuB', 'Francklyn', '33 Amoth Circle');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('mdefont20@yandex.ru', 'F9H1tmYo8A', 'Marcellina', '44746 Monument Trail');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('fgebbe21@businessweek.com', 'FDkp7rL', 'Filip', '27 Autumn Leaf Court');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('mreeken22@harvard.edu', 'NvtG6MU7', 'Mara', '53737 Badeau Junction');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('mbuse23@over-blog.com', 'QR260pmlB53Y', 'Milena', '56451 Kennedy Alley');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('wpotkin24@miitbeian.gov.cn', 'CC8cC85qIYTT', 'Windy', '74430 Basil Junction');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('sdigby25@marketwatch.com', '8MSdQu7M', 'Sonnnie', '907 Sunfield Court');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('mhuffadine26@furl.net', 'McoBbFhGj6v', 'Morganica', '6 Lakeland Avenue');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('rmoralis27@phpbb.com', 'MhdOSVGsxI', 'Rabi', '55 Raven Drive');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('nrecke28@e-recht24.de', 'gg6yeOPoh', 'Noemi', '440 Calypso Avenue');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('bechelle29@yellowbook.com', '1ruwRiqn3', 'Brittney', '7814 Warner Court');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('vlagen2a@mozilla.org', 'b3CfzyOdj', 'Vin', '2133 Bay Alley');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ccasson2b@cam.ac.uk', 'W5sjlBVlb8gz', 'Currie', '17 Dawn Hill');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('bnester2c@multiply.com', 'tv19YeMdC1K', 'Belicia', '11957 Bayside Junction');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('amiell2d@surveymonkey.com', 'Pd33WX', 'Alic', '2 Algoma Circle');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('lkleuer2e@toplist.cz', '969kTWNkjEHe', 'Lionello', '93 High Crossing Trail');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('cjakubowicz2f@cmu.edu', '1deNXU20', 'Carolan', '34 Farragut Terrace');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('gpacey2g@blogs.com', 'w6aWalw', 'Gun', '058 Pond Crossing');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ltezure2h@github.io', 'Td1HwIkP7Mm', 'Layney', '64516 Fallview Road');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('lvalett2i@slideshare.net', 'Qe64k3k', 'Lynea', '0 Carioca Point');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ilambe2j@chronoengine.com', 'rruAEU', 'Irene', '27 Arizona Point');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('dcardis2k@hhs.gov', 'SxwuB9k5', 'Dania', '3 Rieder Point');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('hnast2l@wikimedia.org', 'epIC7y3', 'Harwell', '233 Stang Hill');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('dgrimley2m@aboutads.info', 'VZ78vX', 'Dyana', '45913 Becker Circle');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('mleaney2n@wikispaces.com', 'lyb9MoDWDMgh', 'Maria', '76079 Fallview Alley');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('mgeleman2o@nsw.gov.au', 'nrODYi07L', 'Marchelle', '55720 Roth Trail');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('jcuningham2p@mit.edu', '8xktWy6k', 'Jecho', '4 Barnett Street');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('mkettlewell2q@webmd.com', 'ohTAjbpq', 'Matti', '58078 Marquette Pass');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('logden2r@sciencedaily.com', '7vlodZ5z', 'Lanny', '03034 Lukken Drive');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('lmaken2s@scribd.com', 'STkaBrWKLn', 'Loree', '67 Loftsgordon Terrace');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('lqueree2t@yandex.ru', 'K0T8SGiBD', 'Lincoln', '23785 Westend Trail');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('fgilkison2u@sourceforge.net', 'b1l9JLqAx', 'Friederike', '2 Melvin Hill');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('mgiraudeau2v@freewebs.com', 'YgTxFF6', 'Mathew', '0 Kedzie Way');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ysoltan2w@google.ru', 'BGjNnCjN', 'Yolanda', '94 Hollow Ridge Center');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('kdavidi2x@1688.com', 'omJZep9e', 'Kurt', '481 Gina Avenue');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('amcguire2y@lycos.com', 'EnrTJ3', 'Aharon', '58832 Dixon Alley');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('bgierth2z@altervista.org', 'UOLOPobXhv', 'Benedicto', '96268 Hayes Center');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('criditch30@ucoz.com', 'i0GUOYVy', 'Cristen', '12918 Morrow Road');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('acumberland31@adobe.com', 'QtTnAQk', 'Addia', '8273 Village Drive');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('rricson32@domainmarket.com', 'dtyxFNbFU', 'Rutledge', '2 Mendota Circle');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('cmence33@usa.gov', 'DyZz6b8', 'Corrine', '6951 Dovetail Street');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('fbooeln34@wp.com', 'UuLvfp4S0qN9', 'Frannie', '9 Main Road');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('dtrunchion35@bravesites.com', '7tRyW8NtUM', 'Dalston', '2345 Clyde Gallagher Circle');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('dtrenbay36@usatoday.com', 'K5iR4lvM', 'Dorris', '4 Veith Street');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('aswetland37@shinystat.com', 'B3dE9C', 'Alecia', '5459 Maywood Terrace');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('jbeceril38@wikipedia.org', 'e2ffBhkz', 'Jsandye', '75 Cambridge Trail');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('thrihorovich39@addtoany.com', '8QjwVqI', 'Tarah', '5 Golf Course Point');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('rweald3a@princeton.edu', 'l0oW74dNYc7r', 'Regan', '8 Sachtjen Pass');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('lminci3b@ycombinator.com', '4zgF0RJ5O', 'Launce', '2697 Dottie Junction');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('schilders3c@discuz.net', 'fZpLI2', 'Sashenka', '8804 Mesta Way');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('xmurrie3d@weibo.com', 'PEbDWEhEUhXJ', 'Xymenes', '8661 David Hill');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('wduxbarry3e@nytimes.com', '1KFRRmWdXaSU', 'Winni', '88330 Mayer Center');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('vmelmar3f@addthis.com', 'w2Txb91s', 'Vasili', '611 Green Alley');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('aeuesden3g@slate.com', 'yxBMnCyN9Y', 'Ansell', '901 Eagle Crest Park');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('dplaydon3h@paypal.com', 'ZXbCgKJbLtIW', 'Dolorita', '1 Springs Hill');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ljocelyn3i@mapy.cz', 'gVNxd2HsS0Aj', 'Leonard', '43 Waxwing Center');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('hdilloway3j@kickstarter.com', 'O8eFmaoyq', 'Hadrian', '9068 Susan Court');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('kcolchett3k@arstechnica.com', 'y7pHzT', 'Karoly', '1107 Di Loreto Lane');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('fcowill3l@comsenz.com', '8w3WhV', 'Faun', '1771 Vermont Trail');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('bbrockett3m@artisteer.com', 'zQFJJi9q', 'Bathsheba', '572 Butterfield Trail');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('gpalia3n@bbc.co.uk', 'uIFI352ulxEM', 'Gilberte', '64494 Trailsway Parkway');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ndebeauchamp3o@constantcontact.com', 'Mjm8aLDtgFcB', 'Nickolaus', '18 Logan Avenue');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('mlowdes3p@dedecms.com', '02sh4B1rz', 'Melvyn', '1056 Becker Park');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('hcharteris3q@homestead.com', 'thXzosH', 'Hubert', '2 Maywood Junction');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('atipple3r@washingtonpost.com', 'H2V8jZfTqB', 'Adrian', '5 Village Drive');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('lpendlenton3s@constantcontact.com', 'dNoArRD', 'Laurice', '49198 Tennessee Avenue');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('fshinton3t@seattletimes.com', 'avMPCrs', 'Fernando', '7 Spenser Park');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('rroelofs3u@alibaba.com', 'Daf1G3uXLo', 'Roxana', '62 Granby Avenue');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('cbroadhurst3v@yahoo.com', '5SdTD58b6XQ', 'Cortney', '77946 Buhler Terrace');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('aveale3w@i2i.jp', 'yujipMV8gQvN', 'Aggie', '73 Red Cloud Circle');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('bcantillon3x@ed.gov', 'eOkYTBg', 'Bradley', '7 Nevada Place');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('slujan3y@is.gd', 'eK1UbV', 'Stearne', '36865 Burrows Way');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('nkelshaw3z@theguardian.com', 'F0GHlON7cYW', 'Nicholas', '1 Birchwood Drive');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('imorfell40@army.mil', 'RDaw8W', 'Iggy', '88411 Springview Point');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('jasken41@ft.com', 'AtI5MJT6iPKn', 'Justinn', '24815 Starling Road');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('cbissatt42@elegantthemes.com', '1MUsNthhr', 'Colby', '1 Center Court');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('telward43@elpais.com', 'z1HJWQC46', 'Theresina', '952 Mendota Road');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('pfuxman44@csmonitor.com', 'OV94RaLb8qDn', 'Poul', '51 Blaine Drive');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('malexander45@vinaora.com', '6unXeE52', 'Micheline', '88 South Hill');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('olovett46@hubpages.com', 'MmyeVE07', 'Onfroi', '75534 Hauk Junction');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ioates47@deviantart.com', 'q45MCmCIyy7M', 'Imojean', '4 Walton Trail');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('aallenson48@typepad.com', 'YvTtvQuPo', 'Alyda', '64937 Hooker Park');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('kghiraldi49@hc360.com', '9068pp2mrDg', 'Kathlin', '90 Delaware Terrace');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ngrahame4a@ed.gov', 'OPRKxKDw5ev', 'Niels', '8930 Truax Avenue');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ejoutapaitis4b@xinhuanet.com', 'AOdN0mwkC0y', 'Erda', '9953 Mcbride Pass');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('pdwelling4c@github.io', 'crFCnde', 'Pail', '2668 Arapahoe Street');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ywhiteford4d@mlb.com', 'kd9hFvegbC', 'Yetty', '71696 Crowley Way');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('dletertre4e@deviantart.com', 'DkIiL3vvD2', 'Davita', '32 Cordelia Place');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('efitzpayn4f@japanpost.jp', '8JaCN2H', 'Ebenezer', '6045 Dixon Point');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('flindsey4g@timesonline.co.uk', 'ApSABUYcZa', 'Florian', '946 Monument Pass');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('yribbon4h@chron.com', 'lXbkxT', 'Yehudi', '2 Arapahoe Way');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('hillingsworth4i@slideshare.net', 'HQcdcLHNYqx', 'Hazel', '7090 Alpine Parkway');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ebitten4j@wisc.edu', '4HjnG9e63m8', 'Ethelred', '12926 Gale Street');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('jkamen4k@unicef.org', 'giy2ycFs', 'Jacquelynn', '9 Red Cloud Court');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('bmanthroppe4l@woothemes.com', 'fruH5RhDBLwL', 'Bertha', '438 Reinke Lane');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('reasterbrook4m@lycos.com', 'yT60qIAF1', 'Ravid', '10 Mallard Point');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('snudds4n@digg.com', '7G2dfy', 'Sarene', '8 Sycamore Street');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('aguiu4o@sourceforge.net', 'rBOLiZ9dmEF', 'Agata', '96847 Rieder Pass');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('mmccolley4p@friendfeed.com', 'QkFNQFW6', 'Mord', '28693 Glacier Hill Street');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('rmilius4q@printfriendly.com', 'mH5rrJ', 'Rolfe', '0 Onsgard Way');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ethecham4r@forbes.com', 'Pol3JL', 'Eb', '40 Emmet Parkway');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('bcouvet4s@admin.ch', 'QK6LIohnw', 'Barbra', '576 Logan Place');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('syurov4t@facebook.com', 'ee1et5ox00Oi', 'Samuele', '27 Upham Way');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('bokerin4u@wunderground.com', 'wrxSASDK', 'Berne', '0 Cherokee Terrace');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('cgiorgielli4v@plala.or.jp', 'EI1Bq4RBBFFE', 'Carena', '0 School Junction');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('wlemmertz4w@forbes.com', 'AVVahRfD1', 'Wait', '85 Little Fleur Trail');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('mmattei4x@hud.gov', 'Mz1lF35iZ3El', 'Madelena', '98 Anzinger Lane');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('dstango4y@parallels.com', 'iB3c1x', 'Dniren', '90930 Emmet Way');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('mcasaccia4z@abc.net.au', 'uqvZl17iS0', 'Mitchael', '439 Crownhardt Junction');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('cstockwell50@gizmodo.com', 'QOOEvwqhz7oo', 'Conchita', '64063 Clyde Gallagher Trail');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('aeiler51@devhub.com', 'pRj4LHk', 'Alexia', '4 Green Hill');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('rbinny52@typepad.com', 'tec4pWRwws', 'Rozanne', '5 Thackeray Trail');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('vcristofari53@twitpic.com', 'VKBVCnvr4N', 'Violet', '155 Continental Circle');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('sheaphy54@shop-pro.jp', 'ai2gUNG', 'Shaine', '2891 Merchant Lane');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ecaveill55@cbc.ca', 'pcvrZk', 'Ellswerth', '1 Miller Terrace');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('wlambotin56@oaic.gov.au', 'nQmCFoAy0uh', 'Will', '16 Independence Plaza');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('vfantonetti57@joomla.org', 'C4UHJJaXwD', 'Virginia', '37 Old Gate Alley');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('ntoupe58@twitpic.com', 'gjIHmfUeKn', 'Nap', '474 Rockefeller Point');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('akinworthy59@paginegialle.it', 'WO87iyMeytPK', 'Alexine', '6 Charing Cross Park');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('msapsford5a@archive.org', '6O3OALkZnWW', 'Madelle', '3912 Eagle Crest Hill');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('rfoxley5b@mtv.com', 'IipJn2o9qExS', 'Ron', '8 Buhler Place');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('abusher5c@squarespace.com', 'pGGbCPVMYF1H', 'Alejandrina', '10823 Jackson Avenue');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('sredhouse5d@freewebs.com', 'j2sXBrzjTB', 'Sergei', '055 Grim Place');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('mbullock5e@elegantthemes.com', '85qECJp3bHpQ', 'Massimo', '738 Northland Point');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('reustice5f@squidoo.com', 'jP50chgiHXWq', 'Ruthe', '040 Lyons Pass');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('igurden5g@cafepress.com', 'bXV9tVW', 'Ingaberg', '82170 Rutledge Crossing');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('lberford5h@taobao.com', 'PL8rCwjp', 'Lindy', '6 Novick Circle');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('gcrosby5i@craigslist.org', 'tozQa8', 'Granville', '402 South Place');
INSERT INTO PENGGUNA (email, password, nama, alamat_lengkap)
VALUES ('dcaren5j@wisc.edu', 'FzS4ZM', 'Drucill', '119 Kim Center');


INSERT INTO sponsor (email, logo_sponsor)
VALUES ('vdincey1p@google.ca', 'http://dummyimage.com/146x199.jpg/dddddd/000000');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('ashepley11@simplemachines.org', 'http://dummyimage.com/115x119.jpg/ff4444/ffffff');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('hbremley12@liveinternet.ru', 'http://dummyimage.com/163x187.jpg/ff4444/ffffff');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('mreeken22@harvard.edu', 'http://dummyimage.com/233x206.jpg/ff4444/ffffff');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('dcaren5j@wisc.edu', 'http://dummyimage.com/197x105.jpg/dddddd/000000');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('lberford5h@taobao.com', 'http://dummyimage.com/146x187.jpg/ff4444/ffffff');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('ysoltan2w@google.ru', 'http://dummyimage.com/101x147.jpg/5fa2dd/ffffff');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('vcristofari53@twitpic.com', 'http://dummyimage.com/155x149.jpg/dddddd/000000');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('ndebeauchamp3o@constantcontact.com', 'http://dummyimage.com/177x248.jpg/cc0000/ffffff');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('igreenlees1b@livejournal.com', 'http://dummyimage.com/168x225.jpg/5fa2dd/ffffff');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('kdavidi2x@1688.com', 'http://dummyimage.com/222x133.jpg/5fa2dd/ffffff');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('snudds4n@digg.com', 'http://dummyimage.com/113x194.jpg/dddddd/000000');
INSERT INTO sponsor (email, logo_sponsor) VALUES ('aveale3w@i2i.jp', 'http://dummyimage.com/211x118.jpg/5fa2dd/ffffff');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('mmccolley4p@friendfeed.com', 'http://dummyimage.com/248x113.jpg/dddddd/000000');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('dmurrayc@live.com', 'http://dummyimage.com/131x173.jpg/5fa2dd/ffffff');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('rsellan1y@parallels.com', 'http://dummyimage.com/141x124.jpg/cc0000/ffffff');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('llancley1m@sogou.com', 'http://dummyimage.com/191x198.jpg/dddddd/000000');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('mportigall1u@china.com.cn', 'http://dummyimage.com/174x207.jpg/5fa2dd/ffffff');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('lminci3b@ycombinator.com', 'http://dummyimage.com/247x108.jpg/cc0000/ffffff');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('wlambotin56@oaic.gov.au', 'http://dummyimage.com/137x217.jpg/ff4444/ffffff');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('wpotkin24@miitbeian.gov.cn', 'http://dummyimage.com/219x162.jpg/5fa2dd/ffffff');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('mgiraudeau2v@freewebs.com', 'http://dummyimage.com/134x149.jpg/dddddd/000000');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('bechelle29@yellowbook.com', 'http://dummyimage.com/169x205.jpg/dddddd/000000');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('olovett46@hubpages.com', 'http://dummyimage.com/185x190.jpg/cc0000/ffffff');
INSERT INTO sponsor (email, logo_sponsor)
VALUES ('saizkovitchr@harvard.edu', 'http://dummyimage.com/228x155.jpg/dddddd/000000');


INSERT INTO DONATUR (email, saldo) VALUES ('ndebeauchamp3o@constantcontact.com', 5902228);
INSERT INTO DONATUR (email, saldo) VALUES ('vfantonetti57@joomla.org', 7375802);
INSERT INTO DONATUR (email, saldo) VALUES ('ddagostinox@artisteer.com', 1333193);
INSERT INTO DONATUR (email, saldo) VALUES ('wduxbarry3e@nytimes.com', 6711005);
INSERT INTO DONATUR (email, saldo) VALUES ('dklemket@netlog.com', 4664648);
INSERT INTO DONATUR (email, saldo) VALUES ('kyelyashev0@instagram.com', 2622003);
INSERT INTO DONATUR (email, saldo) VALUES ('fgooders1x@theglobeandmail.com', 9529796);
INSERT INTO DONATUR (email, saldo) VALUES ('bagar1q@angelfire.com', 9404651);
INSERT INTO DONATUR (email, saldo) VALUES ('vdincey1p@google.ca', 8526486);
INSERT INTO DONATUR (email, saldo) VALUES ('wlemmertz4w@forbes.com', 6818435);
INSERT INTO DONATUR (email, saldo) VALUES ('thrihorovich39@addtoany.com', 660526);
INSERT INTO DONATUR (email, saldo) VALUES ('efitzpayn4f@japanpost.jp', 2069668);
INSERT INTO DONATUR (email, saldo) VALUES ('mkettlewell2q@webmd.com', 8389952);
INSERT INTO DONATUR (email, saldo) VALUES ('vmelmar3f@addthis.com', 5700484);
INSERT INTO DONATUR (email, saldo) VALUES ('cbissatt42@elegantthemes.com', 9394218);
INSERT INTO DONATUR (email, saldo) VALUES ('sdevoielss@bizjournals.com', 5247226);
INSERT INTO DONATUR (email, saldo) VALUES ('ctanmano@walmart.com', 5802216);
INSERT INTO DONATUR (email, saldo) VALUES ('cstockwell50@gizmodo.com', 2534686);
INSERT INTO DONATUR (email, saldo) VALUES ('olovett46@hubpages.com', 8694038);
INSERT INTO DONATUR (email, saldo) VALUES ('sheaphy54@shop-pro.jp', 7593618);
INSERT INTO DONATUR (email, saldo) VALUES ('ljocelyn3i@mapy.cz', 5212661);
INSERT INTO DONATUR (email, saldo) VALUES ('ashepley11@simplemachines.org', 5252370);
INSERT INTO DONATUR (email, saldo) VALUES ('aveale3w@i2i.jp', 8354000);
INSERT INTO DONATUR (email, saldo) VALUES ('ecaveill55@cbc.ca', 5386295);
INSERT INTO DONATUR (email, saldo) VALUES ('fsutheringtony@jiathis.com', 7701356);


INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('nkelshaw3z@theguardian.com', '(633) 9159650', '1997-01-28');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('reustice5f@squidoo.com', '(351) 1279735', '1994-06-28');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('ntoupe58@twitpic.com', '(497) 7640738', '1994-06-10');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('mmccolley4p@friendfeed.com', '(625) 8320820', '1990-06-08');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('mspeke1@squarespace.com', '(103) 8822717', '1993-01-11');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('amiell2d@surveymonkey.com', '(282) 5047886', '1998-01-11');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('bokerin4u@wunderground.com', '(572) 7921593', '1993-06-01');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('rbinny52@typepad.com', '(438) 5349510', '1992-05-24');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('lkleuer2e@toplist.cz', '(337) 8300832', '1995-08-17');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('sredhouse5d@freewebs.com', '(171) 6957227', '1992-09-30');
INSERT INTO relawan (email, no_hp, tanggal_lahir)
VALUES ('fgooders1x@theglobeandmail.com', '(719) 2746600', '1998-07-30');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('ncloney1j@google.com.au', '(817) 4220610', '1992-03-05');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('saizkovitchr@harvard.edu', '(603) 3634336', '1997-08-07');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('ywhiteford4d@mlb.com', '(383) 2002630', '1993-05-24');
INSERT INTO relawan (email, no_hp, tanggal_lahir)
VALUES ('ejoutapaitis4b@xinhuanet.com', '(732) 3684438', '1996-03-27');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('rroelofs3u@alibaba.com', '(653) 1354078', '1995-03-03');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('criditch30@ucoz.com', '(169) 8123676', '1998-10-30');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('vcristofari53@twitpic.com', '(104) 4195434', '1997-01-20');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('hbim1o@paginegialle.it', '(538) 8644362', '1993-07-22');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('cstockwell50@gizmodo.com', '(277) 2440183', '1996-07-29');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('tbeak@toplist.cz', '(840) 9513343', '1996-02-28');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('aeiler51@devhub.com', '(175) 4656170', '1994-03-12');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('dplaydon3h@paypal.com', '(852) 6613293', '1997-09-19');
INSERT INTO relawan (email, no_hp, tanggal_lahir)
VALUES ('smcdermott4@chronoengine.com', '(253) 5430159', '1993-08-03');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('cjakubowicz2f@cmu.edu', '(989) 5416386', '1996-05-11');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('dkippingw@nih.gov', '(628) 2400327', '1998-12-25');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('lmaken2s@scribd.com', '(111) 2166705', '1997-12-28');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('ddilgarnob@upenn.edu', '(412) 1401415', '1991-12-09');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('gcrosby5i@craigslist.org', '(361) 8285593', '1996-02-07');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('imorfell40@army.mil', '(871) 5624599', '1995-07-16');
INSERT INTO relawan (email, no_hp, tanggal_lahir)
VALUES ('igreenlees1b@livejournal.com', '(526) 4500452', '1999-01-06');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('dtrenbay36@usatoday.com', '(984) 6333191', '1990-06-07');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('cgannicottu@paginegialle.it', '(252) 9467966', '1995-12-24');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('ljocelyn3i@mapy.cz', '(791) 6757837', '1992-09-05');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('mkettlewell2q@webmd.com', '(706) 9373831', '1992-03-07');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('ctanmano@walmart.com', '(939) 1003176', '1990-05-14');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('sdigby25@marketwatch.com', '(804) 1338807', '1997-10-21');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('mhuffadine26@furl.net', '(378) 6897337', '1994-02-14');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('rweald3a@princeton.edu', '(222) 6578527', '1995-09-14');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('dgoldstrawl@a8.net', '(969) 5719556', '1998-08-10');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('kyelyashev0@instagram.com', '(370) 4531446', '1991-05-31');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('phewins1l@weibo.com', '(476) 6723041', '1997-11-24');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('wlemmertz4w@forbes.com', '(409) 7034628', '1996-11-29');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('wduxbarry3e@nytimes.com', '(974) 5203126', '1991-04-08');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('lsherwill14@yale.edu', '(994) 3549827', '1997-12-09');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('aromaynesv@yandex.ru', '(260) 5563876', '1995-10-31');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('dcardis2k@hhs.gov', '(116) 3190061', '1998-01-10');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('snudds4n@digg.com', '(321) 5028648', '1999-01-10');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('ecaveill55@cbc.ca', '(928) 4415721', '1994-05-25');
INSERT INTO relawan (email, no_hp, tanggal_lahir) VALUES ('pdwelling4c@github.io', '(915) 6813922', '1994-10-23');


INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('dtrenbay36@usatoday.com', 'JDeveloper');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('amiell2d@surveymonkey.com', 'RNA');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('wduxbarry3e@nytimes.com', 'Apache Pig');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('dplaydon3h@paypal.com', 'Perl');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('pdwelling4c@github.io', 'Rheumatology');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('smcdermott4@chronoengine.com', 'DFSS Green Belt');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('igreenlees1b@livejournal.com', 'CISA');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('lmaken2s@scribd.com', 'TQM');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('imorfell40@army.mil', 'Business Intelligence');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('tbeak@toplist.cz', 'FPC 1');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('rroelofs3u@alibaba.com', 'Fixed Income');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('snudds4n@digg.com', 'Songwriting');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('rroelofs3u@alibaba.com', 'OEIC');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('gcrosby5i@craigslist.org', 'IKEv2');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('snudds4n@digg.com', 'Yellow Pages');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('nkelshaw3z@theguardian.com', 'AWR Microwave Office');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('nkelshaw3z@theguardian.com', 'Switching');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('vcristofari53@twitpic.com', 'Django');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('igreenlees1b@livejournal.com', 'MXML');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('imorfell40@army.mil', 'Operating Room');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('dcardis2k@hhs.gov', 'Green Belt');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ejoutapaitis4b@xinhuanet.com', 'AJAX Toolkit');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('rbinny52@typepad.com', 'Kitchen &amp; Bath Design');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('rbinny52@typepad.com', 'Project Portfolio Management');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('aromaynesv@yandex.ru', 'Overseeing Projects');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('cstockwell50@gizmodo.com', 'Candidate Generation');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('snudds4n@digg.com', 'Oil Industry');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('aeiler51@devhub.com', 'RTF');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('dtrenbay36@usatoday.com', 'CCIE R&amp;S');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('wlemmertz4w@forbes.com', 'RAN');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('mhuffadine26@furl.net', 'RHEL');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('cstockwell50@gizmodo.com', 'PTCRB');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('wlemmertz4w@forbes.com', 'RHEV');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('saizkovitchr@harvard.edu', 'CMC');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('lkleuer2e@toplist.cz', 'CDISC');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('imorfell40@army.mil', 'IBM HTTP Server');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ntoupe58@twitpic.com', 'Clinical Supervision');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('amiell2d@surveymonkey.com', 'XPlanner');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('vcristofari53@twitpic.com', 'Youth Outreach');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('cjakubowicz2f@cmu.edu', 'MBTI');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('wduxbarry3e@nytimes.com', 'DTDs');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('aeiler51@devhub.com', 'GMRA');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('smcdermott4@chronoengine.com', 'Not for Profit');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('cstockwell50@gizmodo.com', 'Applied Kinesiology');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('smcdermott4@chronoengine.com', 'Yellow Book');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('pdwelling4c@github.io', 'Qbasic');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ncloney1j@google.com.au', 'Social Skills');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ntoupe58@twitpic.com', 'RPL');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ejoutapaitis4b@xinhuanet.com', 'Hypertension');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ncloney1j@google.com.au', 'Automotive Engineering');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('kyelyashev0@instagram.com', 'Key Person Insurance');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('wlemmertz4w@forbes.com', 'CVA');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('cgannicottu@paginegialle.it', 'Cinematography');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('lmaken2s@scribd.com', 'Thermal Oxidation');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('dtrenbay36@usatoday.com', 'FDS');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('mmccolley4p@friendfeed.com', 'Web Applications');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('fgooders1x@theglobeandmail.com', 'NTFS');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('cstockwell50@gizmodo.com', 'AWR Microwave Office');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ljocelyn3i@mapy.cz', 'Django');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('fgooders1x@theglobeandmail.com', 'SLES');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('rweald3a@princeton.edu', 'DDR');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('lmaken2s@scribd.com', 'Public Speaking');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('nkelshaw3z@theguardian.com', 'Surgery');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('sdigby25@marketwatch.com', 'Service Delivery');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('cstockwell50@gizmodo.com', 'RSVP');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('rweald3a@princeton.edu', 'GMP');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('phewins1l@weibo.com', 'JavaScript Libraries');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('hbim1o@paginegialle.it', 'MHRA');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('amiell2d@surveymonkey.com', 'Kurzweil');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('reustice5f@squidoo.com', 'Zope');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('aromaynesv@yandex.ru', 'JBuilder');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('lmaken2s@scribd.com', 'Circuit Design');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('dtrenbay36@usatoday.com', 'New Homes');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('mkettlewell2q@webmd.com', 'XML Spy');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('fgooders1x@theglobeandmail.com', 'Time &amp; Attendance');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ecaveill55@cbc.ca', 'Vector Illustration');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('mhuffadine26@furl.net', 'WMOS');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('dtrenbay36@usatoday.com', 'Cycling');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('nkelshaw3z@theguardian.com', 'Google Adwords');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('wlemmertz4w@forbes.com', 'XAUI');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('imorfell40@army.mil', 'TV series');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('dcardis2k@hhs.gov', 'Get Along Well with Others');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('igreenlees1b@livejournal.com', 'WSH');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ntoupe58@twitpic.com', 'IT Transformation');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('mmccolley4p@friendfeed.com', 'Sybase IQ');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('lkleuer2e@toplist.cz', 'Trend Analysis');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('rbinny52@typepad.com', 'Kickboxing');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('lsherwill14@yale.edu', 'Git');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ecaveill55@cbc.ca', 'Omnet++');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('fgooders1x@theglobeandmail.com', 'Aviation');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('kyelyashev0@instagram.com', 'OAS Gold');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('cjakubowicz2f@cmu.edu', 'AAT');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('nkelshaw3z@theguardian.com', 'PKI');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('mspeke1@squarespace.com', 'NT 4.0');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('amiell2d@surveymonkey.com', 'Troubleshooting');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('kyelyashev0@instagram.com', 'SR&amp;ED');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('amiell2d@surveymonkey.com', 'Patient Advocacy');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('pdwelling4c@github.io', 'Customs Regulations');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('aromaynesv@yandex.ru', 'Alternative Energy');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ntoupe58@twitpic.com', 'IPS');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('gcrosby5i@craigslist.org', 'Chemical Engineering');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('smcdermott4@chronoengine.com', 'Vessel Operations');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('cjakubowicz2f@cmu.edu', 'XFP');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('dcardis2k@hhs.gov', 'ODD');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('rbinny52@typepad.com', 'Csh');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('kyelyashev0@instagram.com', 'Exercise Physiology');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('pdwelling4c@github.io', 'VLC');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('lsherwill14@yale.edu', 'Ignatian Spirituality');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('sdigby25@marketwatch.com', 'FM Radio');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('rweald3a@princeton.edu', 'ICP-OES');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('tbeak@toplist.cz', 'Dump Truck');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('dplaydon3h@paypal.com', 'PFI');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('wlemmertz4w@forbes.com', 'Vsftpd');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ywhiteford4d@mlb.com', 'JavaBeans');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('sredhouse5d@freewebs.com', 'Financial Risk');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('vcristofari53@twitpic.com', 'Rheumatoid Arthritis');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('smcdermott4@chronoengine.com', 'VMware Fusion');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ejoutapaitis4b@xinhuanet.com', 'Tax Advisory');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('aeiler51@devhub.com', 'IRI Xlerate');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('lsherwill14@yale.edu', 'Snorkeling');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('fgooders1x@theglobeandmail.com', 'Online Travel');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('phewins1l@weibo.com', 'Risk Analysis');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('dtrenbay36@usatoday.com', 'Internet Yellow Pages');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('amiell2d@surveymonkey.com', 'DTMF');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('aromaynesv@yandex.ru', 'User Scenarios');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ntoupe58@twitpic.com', 'VxWorks');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ejoutapaitis4b@xinhuanet.com', 'RS232');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('fgooders1x@theglobeandmail.com', 'Airframe');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('dplaydon3h@paypal.com', 'VC#');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('dcardis2k@hhs.gov', 'Occupational Rehabilitation');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('rroelofs3u@alibaba.com', 'Aerial Cinematography');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('gcrosby5i@craigslist.org', 'Traditional IRA');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('sdigby25@marketwatch.com', 'Owner-managed businesses');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('criditch30@ucoz.com', 'Airline Ticketing');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('tbeak@toplist.cz', 'Koha');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('amiell2d@surveymonkey.com', 'MPBN');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('lkleuer2e@toplist.cz', 'PCM');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('hbim1o@paginegialle.it', 'Outlook');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('cgannicottu@paginegialle.it', 'VxWorks');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('sdigby25@marketwatch.com', 'ODC');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('fgooders1x@theglobeandmail.com', 'Dynamic Positioning');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ddilgarnob@upenn.edu', 'Higher Education Administration');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('phewins1l@weibo.com', 'iOS Development');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('vcristofari53@twitpic.com', 'Automobile');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('cstockwell50@gizmodo.com', 'Galleries');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('aeiler51@devhub.com', 'CPG Industry');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('wlemmertz4w@forbes.com', 'Part-Time CFO Services');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('nkelshaw3z@theguardian.com', 'Utility Billing');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('reustice5f@squidoo.com', 'Food Science');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('rbinny52@typepad.com', 'OLEDs');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('phewins1l@weibo.com', 'Key Account Management');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('dcardis2k@hhs.gov', 'RF Scanners');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ecaveill55@cbc.ca', 'Young Adults');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('saizkovitchr@harvard.edu', 'Black Belt');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ejoutapaitis4b@xinhuanet.com', 'Event Production');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('fgooders1x@theglobeandmail.com', 'New Home Sales');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('imorfell40@army.mil', 'Foreign Trade Zone');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('smcdermott4@chronoengine.com', 'Machine Tools');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('igreenlees1b@livejournal.com', 'DITA XML');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('kyelyashev0@instagram.com', 'WS-Federation');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('smcdermott4@chronoengine.com', 'XMPP');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('mmccolley4p@friendfeed.com', 'Oxy-acetylene');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('lmaken2s@scribd.com', 'TCL');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('aeiler51@devhub.com', 'IHT');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('igreenlees1b@livejournal.com', 'ERP Implementations');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('imorfell40@army.mil', 'iPhoto');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('amiell2d@surveymonkey.com', 'BPEL');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('lsherwill14@yale.edu', 'Payment by Results');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ncloney1j@google.com.au', 'CCIE');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian)
VALUES ('pdwelling4c@github.io', 'Geometric Dimensioning &amp; Tolerancing');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('bokerin4u@wunderground.com', 'Geotechnical Engineering');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('gcrosby5i@craigslist.org', 'NMR Spectroscopy');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('fgooders1x@theglobeandmail.com', 'Vocal');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('lsherwill14@yale.edu', 'Komodo');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('mmccolley4p@friendfeed.com', 'Teacher Training');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('aromaynesv@yandex.ru', 'Lighting');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('wlemmertz4w@forbes.com', 'Natural Gas');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ejoutapaitis4b@xinhuanet.com', 'Small Business');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('wlemmertz4w@forbes.com', 'Vulnerability Management');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('tbeak@toplist.cz', 'PVST+');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('lmaken2s@scribd.com', 'DDoS Mitigation');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('dtrenbay36@usatoday.com', 'Commercial Piloting');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('mspeke1@squarespace.com', 'Cellular Communications');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('aromaynesv@yandex.ru', 'Indoor Air Quality');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('sredhouse5d@freewebs.com', 'RED MX');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('rweald3a@princeton.edu', 'Claim');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('wduxbarry3e@nytimes.com', 'RMS');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('imorfell40@army.mil', 'Strategic HR');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('smcdermott4@chronoengine.com', 'Custom Homes');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('vcristofari53@twitpic.com', 'Epidemiology');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ywhiteford4d@mlb.com', 'NHPA');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('saizkovitchr@harvard.edu', 'Myofascial Release Therapy');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('vcristofari53@twitpic.com', 'Shipping');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('amiell2d@surveymonkey.com', 'Psychometrics');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('dplaydon3h@paypal.com', 'WMOS');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('dtrenbay36@usatoday.com', 'UMA');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('saizkovitchr@harvard.edu', 'Brand Development');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('dcardis2k@hhs.gov', 'Beverage Industry');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('fgooders1x@theglobeandmail.com', 'AC/DC');
INSERT INTO KEAHLIAN_RELAWAN (email, keahlian) VALUES ('ncloney1j@google.com.au', 'Sustainable Development');


INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('dlebbern0@cloudflare.com', 'https://networksolutions.com', 'Tagtune', 'Buckeye', 'Kulautuva', 'Cranberry',
        'Huel LLC', '18751', 'aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('cvose1@livejournal.com', 'https://surveymonkey.com', 'Vimbo', 'Western White Clematis', 'Yongshan',
        'Albuterol Sulfate', 'Gaylord, Nikolaus and Fisher', '15806', 'aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('yfaich2@usatoday.com', 'https://si.edu', 'Jetwire', 'Henbane', 'Tugusirna', 'Chinese Elm Pollen',
        'Kozey, Cummings and Cartwright', '17444', 'aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('echiplen3@skyrock.com', 'https://senate.gov', 'Quinu', 'Bristly Matilija Poppy', 'Tian’an', 'Crest Pro-Health',
        'Upton-Spinka', '19550', 'tidak aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES
  ('fkoeppe4@bbc.co.uk', 'https://ow.ly', 'Realcube', 'Yellow Nutsedge', 'Al ‘Awjah', 'Clonazepam', 'Lowe and Sons',
   '15280', 'aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('apoley5@tinypic.com', 'https://hubpages.com', 'Devpulse', 'Laxmann''s Milkvetch', 'Milagros', 'Biotic-Plus',
        'Mayer, Abshire and Altenwerth', '17902', 'tidak aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('ntuckerman6@about.com', 'https://imageshack.us', 'Bluezoom', 'Bejuco De Miel', 'Pindamonhangaba',
        'Minocycline Hydrochloride', 'Cruickshank Group', '15925', 'aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('srames7@woothemes.com', 'https://google.de', 'Twinder', 'Dioscoreophyllum', 'Kolmården',
        'Eve Lom Radiance Perfected Tinted Moisturiser', 'Breitenberg Inc', '14124', 'aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('bhammett8@nhs.uk', 'http://reddit.com', 'Jabbersphere', 'Hybrid Oak', 'Nîmes', 'Savella',
        'Durgan, Marquardt and Ratke', '18107', 'aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES
  ('blifton9@weather.com', 'http://cmu.edu', 'Jabberstorm', 'California Bedstraw', 'El Triunfo', 'Hamster Epithelium',
   'Stark, Waelchi and Wuckert', '19926', 'aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('afugglesa@unc.edu', 'http://patch.com', 'Yoveo', 'Scolosanthus', 'Komsomolets', 'Lovastatin',
        'Will, Torp and Lueilwitz', '18893', 'aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES
  ('nlegrandb@mysql.com', 'https://ftc.gov', 'Rooxo', 'Oxeye Daisy', 'Göteborg', 'citroma', 'Schaden-Pollich', '14971',
   'tidak aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('abruyetc@microsoft.com', 'https://youtube.com', 'Linkbuzz', 'Gray Rockdaisy', 'Saint Joseph',
        'SBS 41 Medicated Cream', 'Torp Group', '18776', 'aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('chenninghamd@japanpost.jp', 'https://soup.io', 'Flashdog', 'Hillyhock', 'Maojiadian', 'Aspirin', 'Sanford LLC',
        '16375', 'tidak aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('kanthonsene@arstechnica.com', 'http://ask.com', 'Edgewire', 'Great Laurel', 'Helong', 'CLINIMIX',
        'Bradtke, Wisozk and Bahringer', '16840', 'aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('kgarrouldf@blogs.com', 'http://zimbio.com', 'Shuffledrive', 'Polymeridium Lichen', 'Comagascas', 'Anastrozole',
        'Roberts LLC', '16519', 'tidak aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('echanceg@fastcompany.com', 'http://sun.com', 'Edgewire', 'Swamp Paperbark', 'Hyesan-dong',
        'Shopko Cherry SPF 4 Lip Balm', 'Ratke and Sons', '19847', 'tidak aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('bcritchardh@altervista.org', 'https://cornell.edu', 'Vitz', 'Silky Kangaroo Grass', 'Ujar', 'Constipation',
        'Cummings, Kunde and Jaskolski', '19795', 'tidak aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('eyurygyni@lulu.com', 'http://mit.edu', 'Realpoint', 'Elliptic Cockspur Grass', 'Kōfu-shi', 'Oxygen',
        'Kutch, Kozey and Lockman', '19555', 'aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('kvelldenj@photobucket.com', 'http://netscape.com', 'Meevee', 'Hapeman''s Coolwort', 'Jiangdianzi',
        'Ciprofloxacin Hydrochloride', 'Klein LLC', '19319', 'aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('lmarcqk@smh.com.au', 'https://creativecommons.org', 'Meetz', 'Ceboruquillo', 'Kratié', 'Doxepin Hydrochloride',
        'Mayer LLC', '16404', 'aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('jfarransl@mlb.com', 'http://fastcompany.com', 'Tanoodle', 'Bruneau Mariposa Lily', 'Lafia',
        'FLUDROCORTISONE ACETATE', 'Welch and Sons', '14477', 'tidak aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('mwooffm@china.com.cn', 'http://freewebs.com', 'Dazzlesphere', 'Sandmat', 'Canhas', 'Burweed Marsh Elder',
        'Farrell, Reichel and Beatty', '15724', 'tidak aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('hquadrin@home.pl', 'http://accuweather.com', 'Riffpedia', 'Roundhead Rush', 'Scarborough',
        'Diltiazem Hydrochloride', 'Nolan-Torphy', '14505', 'tidak aktif');
INSERT INTO ORGANISASI (email_organisasi, website, nama, provinsi, kabupaten_kota, kecamatan, kelurahan, kode_pos, status_verifikasi)
VALUES ('iwestcarro@princeton.edu', 'http://soundcloud.com', 'Eazzy', 'Soft Brome', 'Radzanów',
        'Cold and Hot Pain Relief Sleeve', 'Bartell-Koss', '16151', 'tidak aktif');


INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('dklemket@netlog.com', 'bhammett8@nhs.uk');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('ysoltan2w@google.ru', 'srames7@woothemes.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('reasterbrook4m@lycos.com', 'afugglesa@unc.edu');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('qsinking@guardian.co.uk', 'afugglesa@unc.edu');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('dcaren5j@wisc.edu', 'bhammett8@nhs.uk');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('ddagostinox@artisteer.com', 'fkoeppe4@bbc.co.uk');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('fsutheringtony@jiathis.com', 'kvelldenj@photobucket.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('wlemmertz4w@forbes.com', 'abruyetc@microsoft.com');
INSERT INTO pengurus_organisasi (email, organisasi)
VALUES ('otrudgiana@scientificamerican.com', 'kgarrouldf@blogs.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('kghiraldi49@hc360.com', 'ntuckerman6@about.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('sheaphy54@shop-pro.jp', 'nlegrandb@mysql.com');
INSERT INTO pengurus_organisasi (email, organisasi)
VALUES ('dveneur1t@huffingtonpost.com', 'chenninghamd@japanpost.jp');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('jprescote3@thetimes.co.uk', 'hquadrin@home.pl');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('rroelofs3u@alibaba.com', 'jfarransl@mlb.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('rmccotter9@google.fr', 'iwestcarro@princeton.edu');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('ejoutapaitis4b@xinhuanet.com', 'srames7@woothemes.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('cstrewtherq@flavors.me', 'fkoeppe4@bbc.co.uk');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('pfuxman44@csmonitor.com', 'jfarransl@mlb.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('cgiorgielli4v@plala.or.jp', 'apoley5@tinypic.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('fjeanequinf@blogtalkradio.com', 'srames7@woothemes.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('flindsey4g@timesonline.co.uk', 'bhammett8@nhs.uk');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('aromaynesv@yandex.ru', 'kvelldenj@photobucket.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('zhuton1k@admin.ch', 'yfaich2@usatoday.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('mgiraudeau2v@freewebs.com', 'cvose1@livejournal.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('dgrimley2m@aboutads.info', 'bhammett8@nhs.uk');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('ngrahame4a@ed.gov', 'apoley5@tinypic.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('cmanolov1g@tamu.edu', 'blifton9@weather.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('aguiu4o@sourceforge.net', 'apoley5@tinypic.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('tbeak@toplist.cz', 'srames7@woothemes.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('nkelshaw3z@theguardian.com', 'echanceg@fastcompany.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('ccasson2b@cam.ac.uk', 'srames7@woothemes.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('dmurrayc@live.com', 'dlebbern0@cloudflare.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('hduham2@i2i.jp', 'srames7@woothemes.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('criditch30@ucoz.com', 'eyurygyni@lulu.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('snudds4n@digg.com', 'chenninghamd@japanpost.jp');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('logden2r@sciencedaily.com', 'jfarransl@mlb.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('bcantillon3x@ed.gov', 'nlegrandb@mysql.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('akubes18@addtoany.com', 'cvose1@livejournal.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('rhaggathm@multiply.com', 'fkoeppe4@bbc.co.uk');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('ltezure2h@github.io', 'lmarcqk@smh.com.au');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('bokerin4u@wunderground.com', 'nlegrandb@mysql.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('bcouvet4s@admin.ch', 'kvelldenj@photobucket.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('ethecham4r@forbes.com', 'iwestcarro@princeton.edu');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('rmilius4q@printfriendly.com', 'echanceg@fastcompany.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('syurov4t@facebook.com', 'ntuckerman6@about.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('jfawson1d@jalbum.net', 'ntuckerman6@about.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('vdincey1p@google.ca', 'kgarrouldf@blogs.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('mmccolley4p@friendfeed.com', 'hquadrin@home.pl');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('jkamen4k@unicef.org', 'eyurygyni@lulu.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('igreenlees1b@livejournal.com', 'jfarransl@mlb.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('gpalia3n@bbc.co.uk', 'chenninghamd@japanpost.jp');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('bolerenshawe@mtv.com', 'bhammett8@nhs.uk');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('vlagen2a@mozilla.org', 'nlegrandb@mysql.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('bgierth2z@altervista.org', 'apoley5@tinypic.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('aeuesden3g@slate.com', 'cvose1@livejournal.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('hdilloway3j@kickstarter.com', 'hquadrin@home.pl');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('ebitten4j@wisc.edu', 'lmarcqk@smh.com.au');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('ceagan10@europa.eu', 'jfarransl@mlb.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('msapsford5a@archive.org', 'echanceg@fastcompany.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('imorfell40@army.mil', 'eyurygyni@lulu.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('wpotkin24@miitbeian.gov.cn', 'mwooffm@china.com.cn');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('hillingsworth4i@slideshare.net', 'ntuckerman6@about.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('mbuse23@over-blog.com', 'jfarransl@mlb.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('mdavinet17@photobucket.com', 'chenninghamd@japanpost.jp');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('ilambe2j@chronoengine.com', 'chenninghamd@japanpost.jp');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('nrecke28@e-recht24.de', 'nlegrandb@mysql.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('bnester2c@multiply.com', 'hquadrin@home.pl');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('ashepley11@simplemachines.org', 'srames7@woothemes.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('lqueree2t@yandex.ru', 'chenninghamd@japanpost.jp');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('yribbon4h@chron.com', 'fkoeppe4@bbc.co.uk');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('sdigby25@marketwatch.com', 'apoley5@tinypic.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('akinworthy59@paginegialle.it', 'dlebbern0@cloudflare.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('jwhoolehan1r@dot.gov', 'ntuckerman6@about.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('mleaney2n@wikispaces.com', 'kgarrouldf@blogs.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('ecaveill55@cbc.ca', 'cvose1@livejournal.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('aallenson48@typepad.com', 'kanthonsene@arstechnica.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('ntoupe58@twitpic.com', 'cvose1@livejournal.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('fleyes1z@godaddy.com', 'hquadrin@home.pl');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('olovett46@hubpages.com', 'eyurygyni@lulu.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('efitzpayn4f@japanpost.jp', 'mwooffm@china.com.cn');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('dletertre4e@deviantart.com', 'ntuckerman6@about.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('ddilgarnob@upenn.edu', 'mwooffm@china.com.cn');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('mlowdes3p@dedecms.com', 'mwooffm@china.com.cn');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('ywhiteford4d@mlb.com', 'dlebbern0@cloudflare.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('jbeceril38@wikipedia.org', 'abruyetc@microsoft.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('pdwelling4c@github.io', 'kanthonsene@arstechnica.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('sheister1w@technorati.com', 'lmarcqk@smh.com.au');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('jasken41@ft.com', 'bhammett8@nhs.uk');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('fbooeln34@wp.com', 'dlebbern0@cloudflare.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('bagar1q@angelfire.com', 'dlebbern0@cloudflare.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('fgebbe21@businessweek.com', 'apoley5@tinypic.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('dstango4y@parallels.com', 'jfarransl@mlb.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('telward43@elpais.com', 'hquadrin@home.pl');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('bmanthroppe4l@woothemes.com', 'lmarcqk@smh.com.au');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('ioates47@deviantart.com', 'kgarrouldf@blogs.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('rmoralis27@phpbb.com', 'eyurygyni@lulu.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('bechelle29@yellowbook.com', 'cvose1@livejournal.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('lvalett2i@slideshare.net', 'abruyetc@microsoft.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('malexander45@vinaora.com', 'echiplen3@skyrock.com');
INSERT INTO pengurus_organisasi (email, organisasi) VALUES ('slujan3y@is.gd', 'cvose1@livejournal.com');


INSERT INTO TUJUAN_ORGANISASI (organisasi, tujuan) VALUES ('apoley5@tinypic.com', 'Guest Lecturing');
INSERT INTO TUJUAN_ORGANISASI (organisasi, tujuan) VALUES ('eyurygyni@lulu.com', 'Oracle E-Business Suite');
INSERT INTO TUJUAN_ORGANISASI (organisasi, tujuan) VALUES ('afugglesa@unc.edu', 'IaaS');
INSERT INTO TUJUAN_ORGANISASI (organisasi, tujuan) VALUES ('kanthonsene@arstechnica.com', 'FSL');
INSERT INTO TUJUAN_ORGANISASI (organisasi, tujuan) VALUES ('echiplen3@skyrock.com', 'RoboHelp');
INSERT INTO TUJUAN_ORGANISASI (organisasi, tujuan) VALUES ('abruyetc@microsoft.com', 'vCenter Server');
INSERT INTO TUJUAN_ORGANISASI (organisasi, tujuan) VALUES ('cvose1@livejournal.com', 'Retirement Planning');
INSERT INTO TUJUAN_ORGANISASI (organisasi, tujuan) VALUES ('echiplen3@skyrock.com', 'Go');
INSERT INTO TUJUAN_ORGANISASI (organisasi, tujuan) VALUES ('eyurygyni@lulu.com', 'Mobile Technology');
INSERT INTO TUJUAN_ORGANISASI (organisasi, tujuan) VALUES ('echanceg@fastcompany.com', 'SBA');


INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('rbinny52@typepad.com', 'hquadrin@home.pl');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('kyelyashev0@instagram.com', 'mwooffm@china.com.cn');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('lkleuer2e@toplist.cz', 'fkoeppe4@bbc.co.uk');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('rroelofs3u@alibaba.com', 'jfarransl@mlb.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('vcristofari53@twitpic.com', 'kgarrouldf@blogs.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('wduxbarry3e@nytimes.com', 'echanceg@fastcompany.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('smcdermott4@chronoengine.com', 'kvelldenj@photobucket.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('ljocelyn3i@mapy.cz', 'kgarrouldf@blogs.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('criditch30@ucoz.com', 'mwooffm@china.com.cn');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('amiell2d@surveymonkey.com', 'abruyetc@microsoft.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('imorfell40@army.mil', 'yfaich2@usatoday.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('aeiler51@devhub.com', 'ntuckerman6@about.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('wduxbarry3e@nytimes.com', 'afugglesa@unc.edu');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('smcdermott4@chronoengine.com', 'fkoeppe4@bbc.co.uk');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('saizkovitchr@harvard.edu', 'cvose1@livejournal.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('wlemmertz4w@forbes.com', 'kanthonsene@arstechnica.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('smcdermott4@chronoengine.com', 'kgarrouldf@blogs.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('cstockwell50@gizmodo.com', 'abruyetc@microsoft.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('amiell2d@surveymonkey.com', 'afugglesa@unc.edu');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('cjakubowicz2f@cmu.edu', 'dlebbern0@cloudflare.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('amiell2d@surveymonkey.com', 'kanthonsene@arstechnica.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('aeiler51@devhub.com', 'chenninghamd@japanpost.jp');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('mkettlewell2q@webmd.com', 'fkoeppe4@bbc.co.uk');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('gcrosby5i@craigslist.org', 'ntuckerman6@about.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('ncloney1j@google.com.au', 'kgarrouldf@blogs.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('mkettlewell2q@webmd.com', 'eyurygyni@lulu.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('dtrenbay36@usatoday.com', 'kvelldenj@photobucket.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('reustice5f@squidoo.com', 'yfaich2@usatoday.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('wduxbarry3e@nytimes.com', 'nlegrandb@mysql.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('nkelshaw3z@theguardian.com', 'lmarcqk@smh.com.au');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('wduxbarry3e@nytimes.com', 'cvose1@livejournal.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('tbeak@toplist.cz', 'iwestcarro@princeton.edu');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('fgooders1x@theglobeandmail.com', 'kvelldenj@photobucket.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('lsherwill14@yale.edu', 'bhammett8@nhs.uk');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('phewins1l@weibo.com', 'chenninghamd@japanpost.jp');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('hbim1o@paginegialle.it', 'nlegrandb@mysql.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('cjakubowicz2f@cmu.edu', 'mwooffm@china.com.cn');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('fgooders1x@theglobeandmail.com', 'lmarcqk@smh.com.au');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('pdwelling4c@github.io', 'mwooffm@china.com.cn');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('rweald3a@princeton.edu', 'chenninghamd@japanpost.jp');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('aeiler51@devhub.com', 'mwooffm@china.com.cn');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('saizkovitchr@harvard.edu', 'apoley5@tinypic.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('rroelofs3u@alibaba.com', 'nlegrandb@mysql.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('dtrenbay36@usatoday.com', 'lmarcqk@smh.com.au');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('nkelshaw3z@theguardian.com', 'kanthonsene@arstechnica.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('ncloney1j@google.com.au', 'echanceg@fastcompany.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('snudds4n@digg.com', 'fkoeppe4@bbc.co.uk');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('phewins1l@weibo.com', 'echiplen3@skyrock.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('ejoutapaitis4b@xinhuanet.com', 'kgarrouldf@blogs.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('rbinny52@typepad.com', 'fkoeppe4@bbc.co.uk');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('reustice5f@squidoo.com', 'eyurygyni@lulu.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('dplaydon3h@paypal.com', 'mwooffm@china.com.cn');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('mspeke1@squarespace.com', 'yfaich2@usatoday.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('dtrenbay36@usatoday.com', 'apoley5@tinypic.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('ncloney1j@google.com.au', 'cvose1@livejournal.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('cstockwell50@gizmodo.com', 'echiplen3@skyrock.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('wlemmertz4w@forbes.com', 'echiplen3@skyrock.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('bokerin4u@wunderground.com', 'lmarcqk@smh.com.au');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('ncloney1j@google.com.au', 'hquadrin@home.pl');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('lkleuer2e@toplist.cz', 'echanceg@fastcompany.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('lsherwill14@yale.edu', 'kvelldenj@photobucket.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('cgannicottu@paginegialle.it', 'bhammett8@nhs.uk');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('rroelofs3u@alibaba.com', 'blifton9@weather.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('kyelyashev0@instagram.com', 'blifton9@weather.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('snudds4n@digg.com', 'nlegrandb@mysql.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('lsherwill14@yale.edu', 'bcritchardh@altervista.org');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('fgooders1x@theglobeandmail.com', 'apoley5@tinypic.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('snudds4n@digg.com', 'bhammett8@nhs.uk');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('rweald3a@princeton.edu', 'bhammett8@nhs.uk');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('snudds4n@digg.com', 'cvose1@livejournal.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('saizkovitchr@harvard.edu', 'kgarrouldf@blogs.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('mkettlewell2q@webmd.com', 'jfarransl@mlb.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('smcdermott4@chronoengine.com', 'afugglesa@unc.edu');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('cstockwell50@gizmodo.com', 'bhammett8@nhs.uk');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('sdigby25@marketwatch.com', 'cvose1@livejournal.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('hbim1o@paginegialle.it', 'eyurygyni@lulu.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('fgooders1x@theglobeandmail.com', 'mwooffm@china.com.cn');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('ljocelyn3i@mapy.cz', 'dlebbern0@cloudflare.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('dtrenbay36@usatoday.com', 'abruyetc@microsoft.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('aromaynesv@yandex.ru', 'eyurygyni@lulu.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('ncloney1j@google.com.au', 'eyurygyni@lulu.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('rweald3a@princeton.edu', 'jfarransl@mlb.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('wlemmertz4w@forbes.com', 'abruyetc@microsoft.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('ntoupe58@twitpic.com', 'ntuckerman6@about.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('wduxbarry3e@nytimes.com', 'jfarransl@mlb.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('ntoupe58@twitpic.com', 'cvose1@livejournal.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('aeiler51@devhub.com', 'blifton9@weather.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('lmaken2s@scribd.com', 'blifton9@weather.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('lkleuer2e@toplist.cz', 'iwestcarro@princeton.edu');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('ecaveill55@cbc.ca', 'eyurygyni@lulu.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('gcrosby5i@craigslist.org', 'dlebbern0@cloudflare.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('mmccolley4p@friendfeed.com', 'eyurygyni@lulu.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('aromaynesv@yandex.ru', 'mwooffm@china.com.cn');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('dcardis2k@hhs.gov', 'yfaich2@usatoday.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('igreenlees1b@livejournal.com', 'hquadrin@home.pl');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('ljocelyn3i@mapy.cz', 'chenninghamd@japanpost.jp');
INSERT INTO relawan_organisasi (email_relawan, organisasi) VALUES ('mkettlewell2q@webmd.com', 'yfaich2@usatoday.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('dtrenbay36@usatoday.com', 'bcritchardh@altervista.org');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('fgooders1x@theglobeandmail.com', 'nlegrandb@mysql.com');
INSERT INTO relawan_organisasi (email_relawan, organisasi)
VALUES ('mmccolley4p@friendfeed.com', 'kvelldenj@photobucket.com');


INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('dlebbern0@cloudflare.com', '6460200696', 'true');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('ntuckerman6@about.com', '1404417370', 'false');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('kvelldenj@photobucket.com', '4400679802', 'true');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('bhammett8@nhs.uk', '3429409187', 'true');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('fkoeppe4@bbc.co.uk', '3326273711', 'true');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('afugglesa@unc.edu', '6397734374', 'true');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('mwooffm@china.com.cn', '3584182891', 'false');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('yfaich2@usatoday.com', '173214061', 'true');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('apoley5@tinypic.com', '6121432136', 'false');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('nlegrandb@mysql.com', '1374737607', 'false');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('blifton9@weather.com', '4510688857', 'false');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('abruyetc@microsoft.com', '5098329175', 'false');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('chenninghamd@japanpost.jp', '2232934322', 'false');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('echiplen3@skyrock.com', '8668092731', 'true');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('kanthonsene@arstechnica.com', '9002101996', 'true');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('srames7@woothemes.com', '1716550149', 'true');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('iwestcarro@princeton.edu', '8062802817', 'false');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('echanceg@fastcompany.com', '4081942455', 'false');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('kgarrouldf@blogs.com', '7877496818', 'false');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('cvose1@livejournal.com', '5519910405', 'false');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('bcritchardh@altervista.org', '5545454505', 'false');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('eyurygyni@lulu.com', '6945124905', 'true');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('lmarcqk@smh.com.au', '91827364650', 'true');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('jfarransl@mlb.com', '6125124905', 'true');
INSERT INTO organisasi_terverifikasi (email_organisasi, nomor_registrasi, status_aktif)
VALUES ('hquadrin@home.pl', '6123456785', 'true');


INSERT INTO donatur_organisasi (donatur, organisasi, tanggal, nominal)
VALUES ('aveale3w@i2i.jp', 'srames7@woothemes.com', '2014-11-24', 490062);
INSERT INTO donatur_organisasi (donatur, organisasi, tanggal, nominal)
VALUES ('ctanmano@walmart.com', 'blifton9@weather.com', '2012-01-07', 315948);
INSERT INTO donatur_organisasi (donatur, organisasi, tanggal, nominal)
VALUES ('ashepley11@simplemachines.org', 'echiplen3@skyrock.com', '2016-03-31', 533379);
INSERT INTO donatur_organisasi (donatur, organisasi, tanggal, nominal)
VALUES ('fsutheringtony@jiathis.com', 'echanceg@fastcompany.com', '2014-11-28', 706143);
INSERT INTO donatur_organisasi (donatur, organisasi, tanggal, nominal)
VALUES ('wduxbarry3e@nytimes.com', 'srames7@woothemes.com', '2012-06-04', 600271);
INSERT INTO donatur_organisasi (donatur, organisasi, tanggal, nominal)
VALUES ('aveale3w@i2i.jp', 'yfaich2@usatoday.com', '2017-10-14', 393682);
INSERT INTO donatur_organisasi (donatur, organisasi, tanggal, nominal)
VALUES ('olovett46@hubpages.com', 'kvelldenj@photobucket.com', '2011-02-12', 997879);
INSERT INTO donatur_organisasi (donatur, organisasi, tanggal, nominal)
VALUES ('olovett46@hubpages.com', 'fkoeppe4@bbc.co.uk', '2012-01-28', 938968);
INSERT INTO donatur_organisasi (donatur, organisasi, tanggal, nominal)
VALUES ('mkettlewell2q@webmd.com', 'cvose1@livejournal.com', '2011-02-03', 146733);
INSERT INTO donatur_organisasi (donatur, organisasi, tanggal, nominal)
VALUES ('sheaphy54@shop-pro.jp', 'echanceg@fastcompany.com', '2015-07-04', 135442);
INSERT INTO donatur_organisasi (donatur, organisasi, tanggal, nominal)
VALUES ('wlemmertz4w@forbes.com', 'cvose1@livejournal.com', '2017-03-12', 459671);
INSERT INTO donatur_organisasi (donatur, organisasi, tanggal, nominal)
VALUES ('ctanmano@walmart.com', 'srames7@woothemes.com', '2011-05-17', 224154);
INSERT INTO donatur_organisasi (donatur, organisasi, tanggal, nominal)
VALUES ('mkettlewell2q@webmd.com', 'echiplen3@skyrock.com', '2015-05-28', 677619);
INSERT INTO donatur_organisasi (donatur, organisasi, tanggal, nominal)
VALUES ('cbissatt42@elegantthemes.com', 'yfaich2@usatoday.com', '2017-11-07', 266082);
INSERT INTO donatur_organisasi (donatur, organisasi, tanggal, nominal)
VALUES ('fgooders1x@theglobeandmail.com', 'srames7@woothemes.com', '2016-11-05', 146638);

INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('cstockwell50@gizmodo.com', 'cvose1@livejournal.com', 1, 'Unsp maternal infec/parastc disease comp preg, third tri',
   '2015-05-29', 9);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('kyelyashev0@instagram.com', 'cvose1@livejournal.com', 2, 'Other contact with other nonvenomous reptiles',
   '2016-03-06', 9);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('aromaynesv@yandex.ru', 'kvelldenj@photobucket.com', 3, 'Other specified congenital malformations of face and neck',
   '2016-07-27', 5);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('kyelyashev0@instagram.com', 'echiplen3@skyrock.com', 4, 'Other specified injury of innominate or subclavian artery',
   '2015-07-14', 4);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala)
VALUES ('kyelyashev0@instagram.com', 'yfaich2@usatoday.com', 5, 'Abrasion of anus, sequela', '2015-10-11', 6);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala)
VALUES ('imorfell40@army.mil', 'iwestcarro@princeton.edu', 6, 'Gender identity disorder, unspecified', '2016-03-29', 4);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala)
VALUES ('ntoupe58@twitpic.com', 'cvose1@livejournal.com', 7, 'Ebstein''s anomaly', '2017-12-09', 9);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('wduxbarry3e@nytimes.com', 'mwooffm@china.com.cn', 8, 'Nondisp oblique fx shaft of unsp rad, 7thM', '2017-08-03', 2);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('vcristofari53@twitpic.com', 'echanceg@fastcompany.com', 9,
   'Other specified injuries of unspecified hip, subs encntr', '2016-02-10', 8);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('mkettlewell2q@webmd.com', 'echiplen3@skyrock.com', 10, 'Injury of unspecified nerve of thorax, sequela',
   '2016-08-17', 1);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala)
VALUES ('ntoupe58@twitpic.com', 'mwooffm@china.com.cn', 11, 'Hypokalemia', '2017-04-16', 5);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('smcdermott4@chronoengine.com', 'echanceg@fastcompany.com', 12,
   'Pedl cyc pasngr inj pk-up truck, pk-up/van nontraf, sequela', '2017-03-31', 2);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('cjakubowicz2f@cmu.edu', 'mwooffm@china.com.cn', 13, 'Traum subdr hem w/o loss of consciousness, sequela',
   '2018-01-03', 9);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('mspeke1@squarespace.com', 'kvelldenj@photobucket.com', 14,
   'Burn due to localized fire on board other powered watercraft', '2016-06-02', 3);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('kyelyashev0@instagram.com', 'echanceg@fastcompany.com', 15,
   'Unsp occupant of snowmobile injured in nontraffic accident', '2015-06-01', 1);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('imorfell40@army.mil', 'iwestcarro@princeton.edu', 16, 'Crohn''s disease, unspecified, with fistula', '2016-04-22',
   9);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('sredhouse5d@freewebs.com', 'echiplen3@skyrock.com', 17, 'Oth disrd of bone density and structure, unsp shoulder',
   '2017-02-22', 7);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala)
VALUES ('dtrenbay36@usatoday.com', 'srames7@woothemes.com', 18, 'Postprocedural pneumothorax', '2018-01-08', 9);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala)
VALUES ('nkelshaw3z@theguardian.com', 'blifton9@weather.com', 19, 'Congenital non-neoplastic nevus', '2016-04-04', 6);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('gcrosby5i@craigslist.org', 'srames7@woothemes.com', 20,
   'Milt op involving fragments from weapons, civilian, sequela', '2015-06-19', 5);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('wduxbarry3e@nytimes.com', 'echiplen3@skyrock.com', 21, 'Nondisp commnt fx shaft of ulna, r arm, 7thN', '2016-08-26',
   8);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('ntoupe58@twitpic.com', 'echiplen3@skyrock.com', 22, 'Inj flexor musc/fasc/tend unsp finger at forearm level, init',
   '2018-03-25', 9);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('cjakubowicz2f@cmu.edu', 'echiplen3@skyrock.com', 23, 'Superficial foreign body of throat, initial encounter',
   '2017-09-13', 1);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('mkettlewell2q@webmd.com', 'yfaich2@usatoday.com', 24, 'Laceration of right renal vein, initial encounter',
   '2018-04-16', 4);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('fgooders1x@theglobeandmail.com', 'iwestcarro@princeton.edu', 25,
   'Unsp physeal fracture of lower end of right tibia, init', '2017-09-16', 8);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('smcdermott4@chronoengine.com', 'cvose1@livejournal.com', 26,
   'Unsp injury of musc/fasc/tend at thi lev, left thigh, subs', '2017-01-23', 9);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('amiell2d@surveymonkey.com', 'echanceg@fastcompany.com', 27,
   'Inj musc/fasc/tend at thigh level, right thigh, sequela', '2018-01-28', 3);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('snudds4n@digg.com', 'echiplen3@skyrock.com', 28, 'Other sickle-cell disorders with splenic sequestration',
   '2016-09-24', 1);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('aromaynesv@yandex.ru', 'cvose1@livejournal.com', 29, 'Nondisp fx of neck of second MC bone, right hand, sequela',
   '2017-06-13', 2);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('dplaydon3h@paypal.com', 'blifton9@weather.com', 30, 'Central dislocation of right hip, subsequent encounter',
   '2015-09-09', 8);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('hbim1o@paginegialle.it', 'iwestcarro@princeton.edu', 31, 'Other superficial bite of right forearm, subs encntr',
   '2017-04-23', 6);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('rroelofs3u@alibaba.com', 'echanceg@fastcompany.com', 32, 'Prsn brd/alit mtrcy injured in clsn w rail trn/veh, init',
   '2017-09-09', 4);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('dtrenbay36@usatoday.com', 'iwestcarro@princeton.edu', 33, 'Toxic effect of chlorine gas, accidental, subs',
   '2015-10-31', 5);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('mhuffadine26@furl.net', 'iwestcarro@princeton.edu', 34, 'Apraxia following nontraumatic subarachnoid hemorrhage',
   '2015-08-25', 8);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('fgooders1x@theglobeandmail.com', 'srames7@woothemes.com', 35,
   'Unsp fx left femur, subs for opn fx type 3A/B/C w routn heal', '2015-10-21', 1);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('wlemmertz4w@forbes.com', 'mwooffm@china.com.cn', 36, 'Other fracture of right femur, sequela', '2017-04-18', 6);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala)
VALUES ('ejoutapaitis4b@xinhuanet.com', 'srames7@woothemes.com', 37, 'Hydrocele, unspecified', '2017-11-24', 3);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('ecaveill55@cbc.ca', 'fkoeppe4@bbc.co.uk', 38, 'Animal-rider injured in collision w nonmtr vehicles, init',
   '2016-11-12', 4);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('cgannicottu@paginegialle.it', 'echiplen3@skyrock.com', 39, 'Disp fx of med condyle of l femr, 7thE', '2015-12-08',
   9);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('wlemmertz4w@forbes.com', 'kvelldenj@photobucket.com', 40, 'Milt op involving fragments from munitions, milt, init',
   '2018-01-08', 2);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('dtrenbay36@usatoday.com', 'echanceg@fastcompany.com', 41,
   'Tox eff of corrosv acids & acid-like substnc, slf-hrm, init', '2016-02-14', 8);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('rweald3a@princeton.edu', 'mwooffm@china.com.cn', 42, 'Temporary auditory threshold shift, left ear', '2017-04-01',
   4);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('hbim1o@paginegialle.it', 'iwestcarro@princeton.edu', 43, 'Nondisp fx of med condyle of unsp femr, 7thH',
   '2017-04-22', 4);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('ncloney1j@google.com.au', 'echiplen3@skyrock.com', 44,
   'Calcifcn and ossifictn of muscles assoc w burns, unsp shldr', '2016-11-30', 8);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('dtrenbay36@usatoday.com', 'fkoeppe4@bbc.co.uk', 45, 'Unsp injury of unsp musc/fasc/tend at forarm lv, right arm',
   '2016-07-08', 6);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('cgannicottu@paginegialle.it', 'echiplen3@skyrock.com', 46,
   'Other acute nonsuppurative otitis media recurrent, unsp ear', '2016-02-20', 8);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('cjakubowicz2f@cmu.edu', 'yfaich2@usatoday.com', 47, 'Driver of bus injured in collision w statnry object nontraf',
   '2017-07-22', 3);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala) VALUES
  ('aeiler51@devhub.com', 'echanceg@fastcompany.com', 48, 'Unsp injury of vein at forearm level, unsp arm, sequela',
   '2018-04-28', 6);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala)
VALUES ('hbim1o@paginegialle.it', 'mwooffm@china.com.cn', 49, 'Leakage of graft of urinary organ', '2016-11-06', 5);
INSERT INTO penilaian_performa (email_relawan, organisasi, id, deskripsi, tgl_penilaian, nilai_skala)
VALUES ('ljocelyn3i@mapy.cz', 'apoley5@tinypic.com', 50, 'Other superficial bite, left lower leg', '2017-04-25', 3);


INSERT INTO sponsor_organisasi (sponsor, organisasi, tanggal, nominal)
VALUES ('vdincey1p@google.ca', 'echanceg@fastcompany.com', '2017-07-04', 180595);
INSERT INTO sponsor_organisasi (sponsor, organisasi, tanggal, nominal)
VALUES ('ashepley11@simplemachines.org', 'mwooffm@china.com.cn', '2010-05-31', 789763);
INSERT INTO sponsor_organisasi (sponsor, organisasi, tanggal, nominal)
VALUES ('hbremley12@liveinternet.ru', 'kvelldenj@photobucket.com', '2017-04-25', 357357);
INSERT INTO sponsor_organisasi (sponsor, organisasi, tanggal, nominal)
VALUES ('mreeken22@harvard.edu', 'srames7@woothemes.com', '2010-06-15', 553166);
INSERT INTO sponsor_organisasi (sponsor, organisasi, tanggal, nominal)
VALUES ('wlambotin56@oaic.gov.au', 'fkoeppe4@bbc.co.uk', '2015-08-13', 892805);
INSERT INTO sponsor_organisasi (sponsor, organisasi, tanggal, nominal)
VALUES ('snudds4n@digg.com', 'srames7@woothemes.com', '2014-09-09', 545437);
INSERT INTO sponsor_organisasi (sponsor, organisasi, tanggal, nominal)
VALUES ('ysoltan2w@google.ru', 'mwooffm@china.com.cn', '2016-10-19', 961456);
INSERT INTO sponsor_organisasi (sponsor, organisasi, tanggal, nominal)
VALUES ('vcristofari53@twitpic.com', 'yfaich2@usatoday.com', '2011-10-17', 119194);
INSERT INTO sponsor_organisasi (sponsor, organisasi, tanggal, nominal)
VALUES ('ndebeauchamp3o@constantcontact.com', 'apoley5@tinypic.com', '2014-05-28', 217253);
INSERT INTO sponsor_organisasi (sponsor, organisasi, tanggal, nominal)
VALUES ('igreenlees1b@livejournal.com', 'echiplen3@skyrock.com', '2017-11-22', 201623);
INSERT INTO sponsor_organisasi (sponsor, organisasi, tanggal, nominal)
VALUES ('kdavidi2x@1688.com', 'blifton9@weather.com', '2017-10-11', 975989);
INSERT INTO sponsor_organisasi (sponsor, organisasi, tanggal, nominal)
VALUES ('snudds4n@digg.com', 'echiplen3@skyrock.com', '2015-03-08', 378928);
INSERT INTO sponsor_organisasi (sponsor, organisasi, tanggal, nominal)
VALUES ('aveale3w@i2i.jp', 'iwestcarro@princeton.edu', '2014-09-22', 451414);
INSERT INTO sponsor_organisasi (sponsor, organisasi, tanggal, nominal)
VALUES ('mmccolley4p@friendfeed.com', 'echiplen3@skyrock.com', '2016-08-01', 805149);
INSERT INTO sponsor_organisasi (sponsor, organisasi, tanggal, nominal)
VALUES ('dmurrayc@live.com', 'srames7@woothemes.com', '2015-08-05', 110528);

INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES
  ('Q556', 'echanceg@fastcompany.com', 'Toughjoyfax', 333950, '2016-08-17', '2017-09-22', 'Correct ureteropelv junc');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('Z1289', 'mwooffm@china.com.cn', 'Bytecard', 121268, '2016-12-22', '2018-01-31', 'Part substern thyroidect');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S72441E', 'kvelldenj@photobucket.com', 'Fixflex', 482537, '2016-09-13', '2017-06-28', 'Other repair of ankle');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S0920', 'srames7@woothemes.com', 'Fintone', 377422, '2016-06-7', '2018-03-9', 'Rev/repl epiretinal pros');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('M6004', 'fkoeppe4@bbc.co.uk', 'Treeflex', 423951, '2016-09-13', '2018-02-19', 'Oth part ostectomy NOS');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S52271P', 'srames7@woothemes.com', 'Job', 266510, '2017-03-7', '2018-02-9', 'Op on 1 extraoc musc NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('T84192A', 'mwooffm@china.com.cn', 'Cardify', 205272, '2016-08-17', '2018-03-23', 'Oth arthrotomy-foot/toe');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('V104XXD', 'yfaich2@usatoday.com', 'Bigtax', 140564, '2017-02-11', '2017-07-10', 'Surg vessel occlus NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S32132S', 'apoley5@tinypic.com', 'Holdlamis', 303189, '2016-09-11', '2017-08-15', 'Radius/ulna division NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S72461F', 'echiplen3@skyrock.com', 'Quo Lux', 354099, '2016-05-20', '2017-08-23', 'Inject/inf thrombo agent');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('I87309', 'blifton9@weather.com', 'Redhold', 468459, '2017-02-12', '2017-08-13', 'Total cystectomy NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('D61810', 'echiplen3@skyrock.com', 'Voyatouch', 462178, '2016-06-11', '2017-10-11', 'Knee arthroscopy');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('T528X1A', 'iwestcarro@princeton.edu', 'Fintone', 177023, '2016-08-23', '2017-10-16', 'Lacrimal punctum probe');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S7512', 'echiplen3@skyrock.com', 'Kanlam', 319912, '2017-01-8', '2018-02-13', 'Occlude abd artery NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('T22619S', 'srames7@woothemes.com', 'Ventosanzap', 120620, '2017-03-25', '2017-11-30', 'Cardiac mapping');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S42016S', 'srames7@woothemes.com', 'Otcom', 440472, '2017-03-15', '2017-10-22', 'Thoracospc pneumonectomy');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('T50Z95D', 'iwestcarro@princeton.edu', 'Cardguard', 140836, '2017-01-22', '2017-09-3', 'Spinal tap');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('H1804', 'echanceg@fastcompany.com', 'Lotlux', 355546, '2016-12-13', '2018-02-26', 'Cell block/pap-eye');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('V872XXD', 'cvose1@livejournal.com', 'Otcom', 356850, '2016-07-26', '2018-02-27', 'Ins d-e stnt sup fem art');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S60551A', 'cvose1@livejournal.com', 'Alpha', 218745, '2017-01-24', '2017-06-10', 'Adrenal repair');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S32031G', 'echanceg@fastcompany.com', 'It', 295319, '2016-06-28', '2018-04-21', 'Dx proc fetus/amnion NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('T592X3S', 'mwooffm@china.com.cn', 'Span', 360484, '2016-12-18', '2018-02-25', 'Ankle fusion');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S66001', 'kvelldenj@photobucket.com', 'Rank', 234518, '2016-10-21', '2018-02-27', 'Bone graft NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES
  ('V401XXD', 'srames7@woothemes.com', 'Lotstring', 255669, '2016-10-20', '2017-09-17', 'Rad pancreaticoduodenect');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('T387X', 'fkoeppe4@bbc.co.uk', 'Voyatouch', 298947, '2016-10-16', '2017-09-30', 'Osteoclasis-patella');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('H348111', 'srames7@woothemes.com', 'Veribet', 211909, '2017-04-27', '2018-03-24', 'Hand synovectomy');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('R801', 'mwooffm@china.com.cn', 'Lotlux', 182685, '2016-07-10', '2018-03-20', 'Remov cholecystost tube');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S32435A', 'yfaich2@usatoday.com', 'Gembucket', 295600, '2016-11-17', '2017-09-20', 'Tooth implantation');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S52002D', 'apoley5@tinypic.com', 'Redhold', 409991, '2016-10-5', '2017-08-2', 'Bact smear-female genit');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S7225XH', 'echiplen3@skyrock.com', 'Treeflex', 471930, '2016-10-10', '2017-05-28', 'Intravas img non-cor OCT');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S51059D', 'blifton9@weather.com', 'Job', 151695, '2016-05-10', '2017-07-2', 'Tot gast w intes interpo');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('T46906S', 'echiplen3@skyrock.com', 'Sonair', 223224, '2017-02-6', '2018-03-17', 'Urin incontin repair NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S59122G', 'iwestcarro@princeton.edu', 'Sub-Ex', 350205, '2016-09-2', '2018-02-3', 'Trnsplnt islets lang NOS');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('M8088XG', 'echiplen3@skyrock.com', 'Matsoft', 498397, '2016-07-16', '2017-10-11', 'Oth op on >l extraoc mus');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('Z384', 'srames7@woothemes.com', 'Tin', 158709, '2016-06-14', '2017-10-10', 'Oth rep int cervical os');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('E070', 'srames7@woothemes.com', 'Domainer', 394836, '2016-12-10', '2018-01-18', 'Amputation thru forearm');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S061X9D', 'iwestcarro@princeton.edu', 'Y-find', 437460, '2016-11-10', '2018-02-3', 'Renal scan/isotope funct');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S75021', 'echanceg@fastcompany.com', 'Redhold', 224669, '2016-11-2', '2017-08-26', 'Gracilis musc transplan');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('J84115', 'cvose1@livejournal.com', 'Overhold', 189822, '2016-08-6', '2018-04-7', 'Narcoanalysis');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('F40248', 'cvose1@livejournal.com', 'Zoolab', 262951, '2016-07-26', '2017-08-21', 'Other counselling');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S30864S', 'echanceg@fastcompany.com', 'Job', 466015, '2017-02-9', '2018-02-7', 'Cl reduct facial fx NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S82819P', 'mwooffm@china.com.cn', 'Job', 342427, '2016-10-26', '2017-04-30', 'Rev knee repl-tibia comp');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES
  ('O3120X3', 'kvelldenj@photobucket.com', 'Y-Solowarm', 101914, '2016-05-26', '2017-12-2', 'Imp/repl brain pulse gen');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S63319D', 'srames7@woothemes.com', 'Subin', 385284, '2016-06-7', '2018-04-15', 'Cls reduc-sep epiphy NOS');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('Q434', 'fkoeppe4@bbc.co.uk', 'Fixflex', 353555, '2017-03-2', '2018-01-21', 'Remov intralum ear FB');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('V514XXA', 'srames7@woothemes.com', 'Gembucket', 268779, '2017-03-22', '2017-09-25', 'Facial bone repair NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('T24692', 'mwooffm@china.com.cn', 'Bamity', 152231, '2016-07-5', '2017-06-23', 'Toxicology-nervous syst');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('Z3A49', 'yfaich2@usatoday.com', 'Greenlam', 381371, '2017-03-16', '2018-04-23', 'Thermography NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S42021A', 'apoley5@tinypic.com', 'Fixflex', 353167, '2017-04-21', '2018-04-19', 'Vaginal suspens & fixat');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES
  ('T22799', 'echiplen3@skyrock.com', 'Toughjoyfax', 416056, '2016-09-5', '2017-09-14', 'Oth lap loc exc dest ova');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S52112G', 'blifton9@weather.com', 'Tres-Zap', 228432, '2016-12-3', '2018-04-9', 'Abdominal vein excision');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('T182XXS', 'echiplen3@skyrock.com', 'Hatity', 351708, '2017-04-19', '2017-07-13', 'Other gu instillation');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('I69091', 'iwestcarro@princeton.edu', 'Biodex', 157088, '2016-12-8', '2018-01-5', 'TRAM flap, pedicled');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('M6110', 'echiplen3@skyrock.com', 'Gembucket', 388155, '2017-04-6', '2017-05-5', 'Destruct joint les NOS');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('M6788', 'srames7@woothemes.com', 'Temp', 457901, '2016-06-23', '2018-01-3', 'Other tenotomy');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('H60502', 'srames7@woothemes.com', 'Tampflex', 110780, '2017-01-15', '2018-02-9', 'Dressing of wound NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('V175', 'iwestcarro@princeton.edu', 'Domainer', 488866, '2016-12-14', '2017-09-12', 'Perc extrac com duc calc');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S31143D', 'echanceg@fastcompany.com', 'Hatity', 157513, '2016-09-9', '2018-03-28', 'Injection into joint');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('O3103X3', 'cvose1@livejournal.com', 'Span', 418801, '2016-07-22', '2017-07-25', 'Alveoloplasty');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S86301A', 'cvose1@livejournal.com', 'Regrant', 114454, '2017-01-18', '2017-07-17', 'Portal contr phlebogram');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('X779XXD', 'echanceg@fastcompany.com', 'Subin', 476373, '2016-08-18', '2017-12-8', 'Oth sleep dis funct test');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S66112', 'mwooffm@china.com.cn', 'Cardguard', 373062, '2016-07-17', '2017-10-15', 'GAP flap, free');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S52256S', 'kvelldenj@photobucket.com', 'Zoolab', 361751, '2017-04-1', '2017-11-4', 'Transabdomin gastroscopy');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S59022P', 'srames7@woothemes.com', 'Alpha', 101498, '2016-08-24', '2018-03-2', 'Intestinal incision NOS');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('O98013', 'fkoeppe4@bbc.co.uk', 'Mat Lam Tam', 339326, '2017-04-6', '2017-12-31', 'Remove spine theca shunt');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S61354S', 'srames7@woothemes.com', 'Span', 365579, '2017-04-28', '2017-10-29', 'Intracranial 02 monitor');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('K824', 'mwooffm@china.com.cn', 'Duobam', 416578, '2016-10-1', '2018-04-16', 'Cord/epid/vas ops NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S52325H', 'yfaich2@usatoday.com', 'Stronghold', 272017, '2017-02-28', '2017-07-9', 'Intestinal x-ray NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('M8739', 'apoley5@tinypic.com', 'Kanlam', 345277, '2016-09-20', '2017-11-5', 'C & s-lower resp');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S36230D', 'echiplen3@skyrock.com', 'Cardify', 154545, '2017-02-5', '2018-02-25', 'Vulvar adhesiolysis');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('V8189XS', 'blifton9@weather.com', 'Flexidy', 496205, '2016-10-4', '2018-04-14', 'Hand tenonectomy NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('Z122', 'echiplen3@skyrock.com', 'Subin', 239217, '2016-10-12', '2017-05-31', 'Vesic fistula repair NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES
  ('I97620', 'iwestcarro@princeton.edu', 'Redhold', 236310, '2016-07-26', '2018-04-27', 'Thorac part exisn thymus');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S99241D', 'echiplen3@skyrock.com', 'Latlux', 468801, '2016-11-17', '2017-05-17', 'Delay opening ileostomy');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('T33832', 'srames7@woothemes.com', 'Toughjoyfax', 376957, '2016-07-14', '2017-05-30', 'Residual root removal');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('T8601', 'srames7@woothemes.com', 'Temp', 205093, '2017-03-4', '2017-08-8', 'Orbitotomy w bone flap');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('C790', 'iwestcarro@princeton.edu', 'Aerified', 439647, '2017-03-10', '2017-10-11', 'Laryngostomy revision');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('I8011', 'echanceg@fastcompany.com', 'Hatity', 413636, '2017-02-13', '2018-04-15', 'C.A.T. scan of kidney');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES
  ('V7981XS', 'cvose1@livejournal.com', 'Bytecard', 269912, '2016-12-27', '2017-12-12', 'Manual muscle funct test');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('Y37001A', 'cvose1@livejournal.com', 'Zamit', 419965, '2016-12-21', '2017-12-21', 'Cell block/pap-lowr resp');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S31140D', 'echanceg@fastcompany.com', 'Pannier', 495776, '2017-04-9', '2018-01-22', 'Cell blk/pap NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('R6521', 'mwooffm@china.com.cn', 'Opela', 254037, '2016-08-27', '2017-12-7', 'Incision pilonidal sinus');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S82126H', 'kvelldenj@photobucket.com', 'Cardguard', 342106, '2017-04-27', '2018-01-18', 'Partial splenectomy');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('H26499', 'srames7@woothemes.com', 'Tampflex', 305195, '2017-03-15', '2017-12-13', 'Hemorrhoidectomy');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('V561XXS', 'fkoeppe4@bbc.co.uk', 'Alpha', 190845, '2016-05-8', '2017-05-6', 'Sutur capsul/lig leg NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S5320', 'srames7@woothemes.com', 'Asoka', 325357, '2017-04-22', '2018-02-4', 'Other acupuncture');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('E103492', 'mwooffm@china.com.cn', 'Cardguard', 404234, '2016-05-5', '2018-04-18', 'Imp/repl brain stim lead');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('Z4931', 'yfaich2@usatoday.com', 'Sub-Ex', 361214, '2017-03-22', '2018-04-11', 'Tooth restorat by inlay');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S7501', 'apoley5@tinypic.com', 'Ronstring', 491545, '2016-12-1', '2017-10-8', 'Facial bone biopsy');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('M7107', 'echiplen3@skyrock.com', 'Fix San', 337833, '2017-02-22', '2017-12-20', 'Suture peptic ulcer NOS');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('V122XXA', 'blifton9@weather.com', 'Greenlam', 445844, '2017-01-23', '2018-04-1', 'Thorac esophagoenter NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('I730', 'echiplen3@skyrock.com', 'Overhold', 236438, '2017-03-15', '2017-10-6', 'Exc chest cage bone les');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES
  ('T404X4', 'iwestcarro@princeton.edu', 'Stronghold', 290799, '2016-05-6', '2017-06-18', 'Prostatic operation NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S31502S', 'echiplen3@skyrock.com', 'Wrapsafe', 376757, '2017-04-21', '2017-12-3', 'Limited interview/evalua');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S8262XS', 'srames7@woothemes.com', 'Otcom', 199946, '2016-08-7', '2017-12-19', 'Oth tib/fib repair/plast');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('T81510A', 'srames7@woothemes.com', 'Tresom', 466126, '2016-10-2', '2017-09-11', 'Mmr administration');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES
  ('T40694A', 'iwestcarro@princeton.edu', 'Bitchip', 487773, '2017-03-20', '2017-05-12', 'Revis cleft palat repair');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S62035B', 'echanceg@fastcompany.com', 'Hatity', 291551, '2016-05-27', '2017-11-21', 'Imp/repl peri stim lead');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S62364P', 'cvose1@livejournal.com', 'Prodder', 313805, '2016-10-24', '2017-07-1', 'Common duct excis NEC');
INSERT INTO kegiatan (kode_unik, organisasi_perancang, judul, dana_dibutuhkan, tanggal_mulai, tanggal_selesai, deskripsi)
VALUES ('S82461K', 'cvose1@livejournal.com', 'Home Ing', 352039, '2017-03-14', '2017-10-18', 'Insert disc pros NOS');


INSERT INTO kategori (kode, nama) VALUES ('0NQJ4ZZ', 'utilisation');
INSERT INTO kategori (kode, nama) VALUES ('03V63DZ', 'capacity');
INSERT INTO kategori (kode, nama) VALUES ('0KQR0ZZ', 'knowledge base');
INSERT INTO kategori (kode, nama) VALUES ('021249F', 'human-resource');
INSERT INTO kategori (kode, nama) VALUES ('0BW087Z', 'interface');
INSERT INTO kategori (kode, nama) VALUES ('0S993ZZ', 'Diverse');
INSERT INTO kategori (kode, nama) VALUES ('B02B1ZZ', 'Up-sized');
INSERT INTO kategori (kode, nama) VALUES ('05990ZZ', 'radical');
INSERT INTO kategori (kode, nama) VALUES ('0PQ03ZZ', 'Operative');
INSERT INTO kategori (kode, nama) VALUES ('0PHD05Z', 'Quality-focused');
INSERT INTO kategori (kode, nama) VALUES ('0QPMX5Z', 'Team-oriented');
INSERT INTO kategori (kode, nama) VALUES ('0LUP4JZ', 'dynamic');
INSERT INTO kategori (kode, nama) VALUES ('0QU407Z', 'methodical');
INSERT INTO kategori (kode, nama) VALUES ('0JWS33Z', 'tangible');
INSERT INTO kategori (kode, nama) VALUES ('0RG8471', 'bifurcated');
INSERT INTO kategori (kode, nama) VALUES ('0KXJ0Z0', 'secured line');
INSERT INTO kategori (kode, nama) VALUES ('0K9P4ZZ', 'access');
INSERT INTO kategori (kode, nama) VALUES ('09NX3ZZ', 'focus group');
INSERT INTO kategori (kode, nama) VALUES ('0K514ZZ', 'access');
INSERT INTO kategori (kode, nama) VALUES ('07990ZZ', 'function');
INSERT INTO kategori (kode, nama) VALUES ('F07M7ZZ', 'Adaptive');
INSERT INTO kategori (kode, nama) VALUES ('037J066', 'Self-enabling');
INSERT INTO kategori (kode, nama) VALUES ('0W054KZ', 'Universal');
INSERT INTO kategori (kode, nama) VALUES ('0T13074', 'Team-oriented');
INSERT INTO kategori (kode, nama) VALUES ('00163K2', 'maximized');

INSERT INTO kategori_kegiatan (kode_kegiatan, kode_kategori) VALUES ('M8088XG', '00163K2');
INSERT INTO kategori_kegiatan (kode_kegiatan, kode_kategori) VALUES ('S36230D', '0KXJ0Z0');
INSERT INTO kategori_kegiatan (kode_kegiatan, kode_kategori) VALUES ('M7107', '0RG8471');
INSERT INTO kategori_kegiatan (kode_kegiatan, kode_kategori) VALUES ('S60551A', '0LUP4JZ');
INSERT INTO kategori_kegiatan (kode_kegiatan, kode_kategori) VALUES ('S82819P', 'B02B1ZZ');
INSERT INTO kategori_kegiatan (kode_kegiatan, kode_kategori) VALUES ('V122XXA', '0K9P4ZZ');
INSERT INTO kategori_kegiatan (kode_kegiatan, kode_kategori) VALUES ('H1804', '03V63DZ');
INSERT INTO kategori_kegiatan (kode_kegiatan, kode_kategori) VALUES ('S32132S', '03V63DZ');
INSERT INTO kategori_kegiatan (kode_kegiatan, kode_kategori) VALUES ('S30864S', '09NX3ZZ');
INSERT INTO kategori_kegiatan (kode_kegiatan, kode_kategori) VALUES ('Z4931', '09NX3ZZ');
INSERT INTO kategori_kegiatan (kode_kegiatan, kode_kategori) VALUES ('S51059D', '0BW087Z');
INSERT INTO kategori_kegiatan (kode_kegiatan, kode_kategori) VALUES ('Z384', '0PQ03ZZ');
INSERT INTO kategori_kegiatan (kode_kegiatan, kode_kategori) VALUES ('Z122', '0PHD05Z');
INSERT INTO kategori_kegiatan (kode_kegiatan, kode_kategori) VALUES ('S62364P', '05990ZZ');
INSERT INTO kategori_kegiatan (kode_kegiatan, kode_kategori) VALUES ('S86301A', '0KQR0ZZ');

INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('T50Z95D', 'LIDOCAINE HYDROCHLORIDE', 202, 4548);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('E070', 'metoprolol tartrate', 629, 5906);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('M6004', 'Bacitracin Dimethicone Zinc Oxide', 453, 5846);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('K824', 'CEFOXITIN SODIUM', 102, 8714);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('T592X3S', 'Benzocaine', 868, 6613);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('J84115', 'Guaifenesin, Dextromethorphan HBr', 639, 4213);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('T40694A', 'acetaminophen', 953, 2970);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('S52271P', 'Ibuprofen', 951, 8668);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('J84115', 'Aconitum nap., Anacardium orientale, Arg. nit.', 214, 6295);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('Z3A49', 'TRICLOSAN', 604, 6735);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('T528X1A', 'Mexiletine Hydrochloride', 177, 4860);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('S31140D', 'TRICLOSAN', 597, 9794);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('S52256S', 'Labetalol hydrochloride', 418, 3926);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('V514XXA', 'Aranea diadema 12X, Conium maculatum 30X', 451, 6544);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('V872XXD', 'Anticoagulant Citrate', 352, 6019);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('S0920', 'CARBOplatin', 890, 2135);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('M8739', 'Fosinopril sodium', 433, 5260);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('F40248', 'Acetaminophen and Codeine Phosphate', 143, 8680);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('S75021', 'ezogabine', 393, 5286);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('S72441E', 'FUROSEMIDE', 582, 6657);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('T387X', 'Dextromethorphan Hydrobromide', 565, 8527);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('S66001', 'pregabalin', 358, 9784);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('S82126H', 'Lisinopril and Hydrochlorothiazide', 609, 8264);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('T84192A', 'OCTINOXATE, TITANIUM DIOXIDE', 680, 1130);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('H60502', 'terconazole', 578, 8550);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('F40248', 'DIOSCOREA VILLOSA ROOT, GINGER', 739, 9360);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('T8601', 'Gabapentin', 324, 4220);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('S7512', 'oxycodone hydrochloride', 170, 4591);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('S32031G', 'Quinapril Hydrochloride', 910, 6236);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('O98013', 'Rough Marsh Elder', 257, 9421);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('I97620', 'Ibuprofen', 602, 7967);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('S63319D', 'Hydroquinone', 404, 6317);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('Z4931', 'TITANIUM DIOXIDE, ZINC OXIDE', 883, 1892);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('S5320', 'octreotide acetate', 154, 4091);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('S99241D', 'Ropinirole Hydrochloride', 113, 9305);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('I69091', 'Citalopram Hydrobromide', 518, 5426);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('S42016S', 'acyclovir', 894, 2617);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('Q556', 'Alcohol, Benzethonium Chloride', 654, 3866);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('S51059D', 'Nicotine Polacrilex', 106, 8955);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('S42021A', 'Hydrogen Peroxide', 567, 4055);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('H348111', 'TITANIUM DIOXIDE and Zinc Oxide', 391, 3073);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('E070', 'Levetiracetam', 876, 5498);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('H348111', 'Cucumber', 845, 8848);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('Z4931', 'Benzoyl Peroxide', 924, 9896);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('Z3A49', 'Imiquimod', 600, 9954);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('S59022P', 'ergocalciferol', 549, 8278);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('H60502', 'Phenylephrine hydrochloride', 688, 3626);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('H348111', 'Meloxicam', 711, 5781);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max) VALUES ('S82126H', 'Estradiol', 400, 5680);
INSERT INTO reward (kode_kegiatan, barang_reward, harga_min, harga_max)
VALUES ('T24692', 'Carbetapentane Citrate', 787, 9753);

INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('O3120X9', 'Q556', 'VP Accounting',
   'Continuing pregnancy after intrauterine death of one fetus or more, unspecified trimester, other fetus',
   '2017-05-21', '2016-08-17');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('S85919A', 'Z1289', 'Nurse',
   'Laceration of unspecified blood vessel at lower leg level, unspecified leg, initial encounter', '2017-12-14',
   '2016-12-22');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('L984', 'S72441E', 'Financial Advisor', 'Non-pressure chronic ulcer of skin, not elsewhere classified', '2017-05-12',
   '2016-09-13');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('H5014', 'S0920', 'Account Representative III', 'Monocular exotropia with other noncomitancies', '2017-06-26',
   '2016-06-07');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('T23042A', 'M6004', 'Health Coach II',
   'Burn of unspecified degree of multiple left fingers (nail), including thumb, initial encounter', '2017-09-21',
   '2016-09-13');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('S06305D', 'S52271P', 'VP Product Management',
   'Unspecified focal traumatic brain injury with loss of consciousness greater than 24 hours with return to pre-existing conscious level, subsequent encounter',
   '2018-04-10', '2017-03-07');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('T8181XS', 'T84192A', 'Cost Accountant', 'Complication of inhalation therapy, sequela', '2018-03-20', '2016-08-17');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('T23191', 'V104XXD', 'Teacher', 'Burn of first degree of multiple sites of right wrist and hand', '2017-12-31',
   '2017-02-11');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan)
VALUES ('M8475', 'S32132S', 'Environmental Tech', 'Atypical femoral fracture', '2017-10-27', '2016-09-11');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('I698', 'S72461F', 'Occupational Therapist', 'Sequelae of other cerebrovascular diseases', '2017-06-11',
   '2016-05-20');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('V9386', 'I87309', 'Administrative Assistant IV',
   'Other injury due to other accident on board (nonpowered) inflatable craft', '2017-06-04', '2017-02-12');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('X80', 'D61810', 'Senior Editor', 'Intentional self-harm by jumping from a high place', '2017-10-07', '2016-06-11');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('S43084', 'T528X1A', 'Nuclear Power Engineer', 'Other dislocation of right shoulder joint', '2018-03-09',
   '2016-08-23');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('S82291B', 'S7512', 'Health Coach I',
   'Other fracture of shaft of right tibia, initial encounter for open fracture type I or II', '2018-03-31',
   '2017-01-08');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('C8215', 'T22619S', 'Geological Engineer',
   'Follicular lymphoma grade II, lymph nodes of inguinal region and lower limb', '2017-05-15', '2017-03-25');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan)
VALUES ('S6321', 'S42016S', 'Editor', 'Subluxation of metacarpophalangeal joint of finger', '2018-03-11', '2017-03-15');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('M05262', 'T50Z95D', 'Librarian', 'Rheumatoid vasculitis with rheumatoid arthritis of left knee', '2017-07-01',
   '2017-01-22');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('E0837X1', 'H1804', 'Senior Financial Analyst',
   'Diabetes mellitus due to underlying condition with diabetic macular edema, resolved following treatment, right eye',
   '2017-07-13', '2016-12-13');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan)
VALUES ('L898', 'V872XXD', 'Web Developer III', 'Pressure ulcer of other site', '2018-01-28', '2016-07-26');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('V379', 'S60551A', 'Geological Engineer',
   'Unspecified occupant of three-wheeled motor vehicle injured in collision with fixed or stationary object in traffic accident',
   '2018-02-15', '2017-01-24');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('S82044S', 'S32031G', 'Programmer Analyst III', 'Nondisplaced comminuted fracture of right patella, sequela',
   '2018-02-24', '2016-06-28');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('S52326N', 'T592X3S', 'Electrical Engineer',
   'Nondisplaced transverse fracture of shaft of unspecified radius, subsequent encounter for open fracture type IIIA, IIIB, or IIIC with nonunion',
   '2017-10-06', '2016-12-18');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('S52112S', 'S66001', 'Statistician I', 'Torus fracture of upper end of left radius, sequela', '2018-04-21',
   '2016-10-21');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan)
VALUES ('T8021', 'V401XXD', 'VP Accounting', 'Infection due to central venous catheter', '2017-09-04', '2016-10-20');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('S72134Q', 'T387X', 'Clinical Specialist',
   'Nondisplaced apophyseal fracture of right femur, subsequent encounter for open fracture type I or II with malunion',
   '2018-03-25', '2016-10-16');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('N066', 'H348111', 'Business Systems Development Analyst', 'Isolated proteinuria with dense deposit disease',
   '2018-02-09', '2017-04-27');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('E8419', 'R801', 'Research Associate', 'Cystic fibrosis with other intestinal manifestations', '2018-04-02',
   '2016-07-10');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('H18021', 'S32435A', 'Software Engineer I', 'Argentous corneal deposits, right eye', '2017-12-31', '2016-11-17');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('S12111S', 'S52002D', 'Human Resources Manager', 'Posterior displaced Type II dens fracture, sequela', '2018-04-13',
   '2016-10-05');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('W9301XD', 'S7225XH', 'Budget/Accounting Analyst I', 'Contact with dry ice, subsequent encounter', '2018-01-31',
   '2016-10-10');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('S89011D', 'S51059D', 'Recruiter',
   'Salter-Harris Type I physeal fracture of upper end of right tibia, subsequent encounter for fracture with routine healing',
   '2018-03-01', '2016-05-10');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan)
VALUES ('C562', 'T46906S', 'Food Chemist', 'Malignant neoplasm of left ovary', '2017-07-25', '2017-02-06');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('T402X2D', 'S59122G', 'Recruiting Manager',
   'Poisoning by other opioids, intentional self-harm, subsequent encounter', '2017-11-24', '2016-09-02');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('M8582', 'M8088XG', 'Programmer Analyst I', 'Other specified disorders of bone density and structure, upper arm',
   '2017-08-28', '2016-07-16');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('S31654D', 'Z384', 'Director of Sales',
   'Open bite of abdominal wall, left lower quadrant with penetration into peritoneal cavity, subsequent encounter',
   '2017-06-26', '2016-06-14');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('S52099D', 'E070', 'Editor',
   'Other fracture of upper end of unspecified ulna, subsequent encounter for closed fracture with routine healing',
   '2017-07-12', '2016-12-10');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan)
VALUES ('M798', 'S061X9D', 'Office Assistant IV', 'Other specified soft tissue disorders', '2018-03-26', '2016-11-10');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('S93412D', 'S75021', 'Human Resources Assistant I',
   'Sprain of calcaneofibular ligament of left ankle, subsequent encounter', '2018-02-17', '2016-11-02');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan)
VALUES ('S279', 'J84115', 'Design Engineer', 'Injury of unspecified intrathoracic organ', '2017-05-20', '2016-08-06');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('Y30', 'F40248', 'Teacher', 'Falling, jumping or pushed from a high place, undetermined intent', '2018-01-14',
   '2016-07-26');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('T2691XD', 'S30864S', 'Account Representative IV',
   'Corrosion of right eye and adnexa, part unspecified, subsequent encounter', '2017-07-28', '2017-02-09');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan)
VALUES ('T1731', 'S82819P', 'VP Product Management', 'Gastric contents in larynx', '2017-09-06', '2016-10-26');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('W16811D', 'O3120X3', 'Teacher',
   'Jumping or diving into other water striking water surface causing drowning and submersion, subsequent encounter',
   '2017-08-08', '2016-05-26');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan)
VALUES ('E058', 'S63319D', 'Data Coordiator', 'Other thyrotoxicosis', '2017-11-05', '2016-06-07');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('Y36250S', 'Q434', 'Tax Accountant',
   'War operations involving fragments from munitions, military personnel, sequela', '2017-10-07', '2017-03-02');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('S72009D', 'V514XXA', 'Internal Auditor',
   'Fracture of unspecified part of neck of unspecified femur, subsequent encounter for closed fracture with routine healing',
   '2017-11-22', '2017-03-22');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('M7580', 'T24692', 'Mechanical Systems Engineer', 'Other shoulder lesions, unspecified shoulder', '2017-10-31',
   '2016-07-05');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('S7411XA', 'Z3A49', 'Dental Hygienist',
   'Injury of femoral nerve at hip and thigh level, right leg, initial encounter', '2017-10-04', '2017-03-16');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan) VALUES
  ('S92531P', 'S42021A', 'Budget/Accounting Analyst III',
   'Displaced fracture of distal phalanx of right lesser toe(s), subsequent encounter for fracture with malunion',
   '2017-06-02', '2017-04-21');
INSERT INTO berita (kode_unik, kegiatan, judul, deskripsi, tgl_update, tgl_kegiatan)
VALUES ('E70319', 'T22799', 'Engineer IV', 'Ocular albinism, unspecified', '2018-04-01', '2016-09-05');

INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('ndebeauchamp3o@constantcontact.com', 'Q556', '2017-06-19', 185508);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('vfantonetti57@joomla.org', 'Z1289', '2017-08-26', 373020);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('ddagostinox@artisteer.com', 'S72441E', '2017-05-29', 182174);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('wduxbarry3e@nytimes.com', 'S0920', '2018-02-22', 192967);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('dklemket@netlog.com', 'M6004', '2017-08-05', 448222);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('kyelyashev0@instagram.com', 'S52271P', '2018-01-30', 466587);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('fgooders1x@theglobeandmail.com', 'T84192A', '2018-04-28', 289689);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('bagar1q@angelfire.com', 'V104XXD', '2017-11-13', 362501);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('vdincey1p@google.ca', 'S32132S', '2018-03-28', 301413);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('wlemmertz4w@forbes.com', 'S72461F', '2018-01-25', 410362);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('thrihorovich39@addtoany.com', 'I87309', '2018-04-04', 384759);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('efitzpayn4f@japanpost.jp', 'D61810', '2018-04-12', 370930);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('mkettlewell2q@webmd.com', 'T528X1A', '2017-10-27', 433881);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('vmelmar3f@addthis.com', 'S7512', '2018-04-22', 140857);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('cbissatt42@elegantthemes.com', 'T22619S', '2018-02-16', 475044);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('sdevoielss@bizjournals.com', 'S42016S', '2018-01-07', 287158);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('ctanmano@walmart.com', 'T50Z95D', '2017-07-14', 463674);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('cstockwell50@gizmodo.com', 'H1804', '2017-06-19', 255557);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('olovett46@hubpages.com', 'V872XXD', '2018-01-24', 115539);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('sheaphy54@shop-pro.jp', 'S60551A', '2017-10-28', 209727);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('ljocelyn3i@mapy.cz', 'S32031G', '2017-08-15', 305170);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('ashepley11@simplemachines.org', 'T592X3S', '2017-11-11', 192061);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('aveale3w@i2i.jp', 'S66001', '2017-07-29', 138766);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('ecaveill55@cbc.ca', 'V401XXD', '2017-07-19', 444063);
INSERT INTO donatur_kegiatan (donatur, kegiatan, tanggal, nominal)
VALUES ('fsutheringtony@jiathis.com', 'T387X', '2018-03-26', 476079);

INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('dlebbern0@cloudflare.com', '2011-09-19',
        'Hyperplasia of prostate, unspecified, without urinary obstruction and other lower urinary symptoms (LUTS)',
        7541, 8446, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('cvose1@livejournal.com', '2016-04-24', 'Excessive physical exertion', 1456, 3796, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('yfaich2@usatoday.com', '2016-11-08', 'Unqualified visual loss, one eye', 6416, 7058, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echiplen3@skyrock.com', '2010-06-10',
        'Tuberculosis of lung with cavitation, bacteriological or histological examination not done', 9840, 7170,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('fkoeppe4@bbc.co.uk', '2010-05-06', 'Other specified perinatal disorders of digestive system', 2602, 5581, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('apoley5@tinypic.com', '2017-05-01', 'Mechanical complication due to coronary bypass graft', 6730, 4968, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('ntuckerman6@about.com', '2011-10-07',
        'Extradural hemorrhage following injury without mention of open intracranial wound, with prolonged [more than 24 hours] loss of consciousness without return to pre-existing conscious level',
        6753, 1720, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('srames7@woothemes.com', '2016-10-11', 'Other specified hemiplegia and hemiparesis affecting dominant side', 7362,
   2070, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bhammett8@nhs.uk', '2015-02-23', 'Endomyocardial fibrosis', 1460, 5717, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('blifton9@weather.com', '2016-04-28', 'Other and unspecified water transport accident injuring swimmer', 2010, 2503,
   'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('afugglesa@unc.edu', '2016-11-14', 'Malignant neoplasm of pituitary gland and craniopharyngeal duct', 1031, 7288,
   'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('nlegrandb@mysql.com', '2018-02-16', 'Pannus (corneal)', 2277, 9225, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('abruyetc@microsoft.com', '2015-03-17', 'Accidental poisoning by chloral hydrate group', 3948, 4313, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('chenninghamd@japanpost.jp', '2012-10-16', 'Other disorders of lactation, postpartum condition or complication',
        1997, 1912, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('kanthonsene@arstechnica.com', '2010-06-06', 'Fever presenting with conditions classified elsewhere', 4471, 3166,
   'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kgarrouldf@blogs.com', '2013-02-14',
        'Breech or other malpresentation successfully converted to cephalic presentation, delivered, with or without mention of antepartum condition',
        7088, 8615, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echanceg@fastcompany.com', '2015-09-11',
        'Retroverted and incarcerated gravid uterus, delivered, with mention of antepartum condition', 2903, 6771,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bcritchardh@altervista.org', '2017-06-03',
        'Other primary progressive tuberculosis, bacteriological or histological examination not done', 9677, 6510,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('eyurygyni@lulu.com', '2011-06-16', 'Myocardial degeneration', 5499, 3600, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kvelldenj@photobucket.com', '2011-08-19', 'Transient arthropathy, other specified sites', 5009, 9074, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('lmarcqk@smh.com.au', '2015-06-26', 'Unspecified transient mental disorder in conditions classified elsewhere', 5080,
   6647, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('jfarransl@mlb.com', '2012-04-09',
        'Arthropathy associated with other infectious and parasitic diseases, shoulder region', 3714, 7547, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('mwooffm@china.com.cn', '2011-02-22',
        'Full-thickness skin loss [third degree, not otherwise specified] of multiple sites [except with eye] of face, head, and neck',
        6892, 1702, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('hquadrin@home.pl', '2010-11-05',
        'Open fractures involving skull or face with other bones, without mention of intracranial injury, with concussion, unspecified',
        6400, 5341, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('iwestcarro@princeton.edu', '2011-03-05', 'Omphalocele', 9247, 3498, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('dlebbern0@cloudflare.com', '2016-12-31',
        'Injury to spleen without mention of open wound into cavity, massive parenchymal disruption', 5302, 1014,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('cvose1@livejournal.com', '2013-11-13', 'Other symptoms involving cardiovascular system', 2813, 5673, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('yfaich2@usatoday.com', '2013-08-24',
        'Cortex (cerebral) laceration without mention of open intracranial wound, with prolonged [more than 24 hours] loss of consciousness and return to pre-existing conscious level',
        1872, 4518, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echiplen3@skyrock.com', '2011-08-23',
        'Unspecified complication of pregnancy, unspecified as to episode of care or not applicable', 5261, 6159,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('fkoeppe4@bbc.co.uk', '2011-06-18', 'Hemorrhage of gastrointestinal tract, unspecified', 7180, 2389, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('apoley5@tinypic.com', '2014-06-24', 'Pyrazole derivatives causing adverse effects in therapeutic use', 4738, 5127,
   'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('ntuckerman6@about.com', '2018-04-02', 'Extravaginal torsion of spermatic cord', 9189, 8920, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('srames7@woothemes.com', '2018-04-03',
        'Extradural hemorrhage following injury with open intracranial wound, with no loss of consciousness', 3299,
        4250, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bhammett8@nhs.uk', '2017-08-15',
        'Injury due to war operations by fragments from person-borne improvised explosive device [IED]', 4422, 6629,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('blifton9@weather.com', '2011-10-16', 'Chronic kidney disease, Stage V', 2929, 8513, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('afugglesa@unc.edu', '2010-08-04',
        'Fetal hematologic conditions, unspecified as to episode of care or not applicable', 5561, 2912, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('nlegrandb@mysql.com', '2013-06-30', 'Closed unspecified fracture of pelvis', 1227, 2091, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('abruyetc@microsoft.com', '2011-05-16',
        'Subarachnoid hemorrhage following injury without mention of open intracranial wound, unspecified state of consciousness',
        1855, 9332, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('chenninghamd@japanpost.jp', '2012-07-29', 'Unspecified derangement of joint, forearm', 2418, 2723, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('kanthonsene@arstechnica.com', '2014-01-14', 'Oligohydramnios, antepartum condition or complication', 7689, 2414,
   'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kgarrouldf@blogs.com', '2015-07-08',
        'Other causes of obstructed labor, delivered, with or without mention of antepartum condition', 3620, 3529,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echanceg@fastcompany.com', '2016-06-06', 'Vertebral artery syndrome', 1783, 3700, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bcritchardh@altervista.org', '2013-10-03', 'Herpes simplex otitis externa', 2927, 2440, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('eyurygyni@lulu.com', '2011-08-19', 'Leukocytosis, unspecified', 5415, 5938, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('kvelldenj@photobucket.com', '2013-11-12', 'Thyroid dysfunction of mother, postpartum condition or complication',
   8034, 7989, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('lmarcqk@smh.com.au', '2013-03-14',
        'Traumatic amputation of arm and hand (complete) (partial), bilateral [any level], without mention of complication',
        6835, 3257, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('jfarransl@mlb.com', '2018-02-11', 'Derangement of anterior horn of medial meniscus', 6924, 5109, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('mwooffm@china.com.cn', '2012-02-11', 'Other specified arthropathy, shoulder region', 2636, 7715, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('hquadrin@home.pl', '2011-02-14', 'Benign neoplasm of other specified sites of respiratory and intrathoracic organs',
   9486, 7310, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('iwestcarro@princeton.edu', '2011-11-27',
        'Other accidental submersion or drowning in water transport accident injuring unspecified person', 5585, 9678,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('dlebbern0@cloudflare.com', '2012-02-27', 'Carcinoma in situ of skin, site unspecified', 1069, 4985, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('cvose1@livejournal.com', '2014-07-09',
        'Other specified indications for care or intervention related to labor and delivery, delivered, with or without mention of antepartum condition',
        4516, 8704, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('yfaich2@usatoday.com', '2013-07-18',
        'Diabetes with ophthalmic manifestations, type I [juvenile type], not stated as uncontrolled', 3719, 1670,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('echiplen3@skyrock.com', '2015-07-16', 'Antimetabolic agents affecting fetus or newborn via placenta or breast milk',
   3644, 6717, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('fkoeppe4@bbc.co.uk', '2014-06-12',
        'Chromosomal abnormality in fetus, affecting management of mother, unspecified as to episode of care or not applicable',
        5565, 9449, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('apoley5@tinypic.com', '2011-08-12',
        'Other and unspecified superficial injury of other, multiple, and unspecified sites, without mention of infection',
        4884, 4982, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('ntuckerman6@about.com', '2013-07-05', 'Atherosclerosis of unspecified bypass graft of the extremities', 3852, 3074,
   'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('srames7@woothemes.com', '2017-04-13', 'Acute alcoholic intoxication in alcoholism, episodic', 4165, 4102, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bhammett8@nhs.uk', '2017-10-07',
        'Other cardiovascular diseases of mother, delivered, with mention of postpartum complication', 8384, 8448,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('blifton9@weather.com', '2016-01-06', 'Personal history of malignant neoplasm of female genital organ, unspecified',
   5335, 9690, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('afugglesa@unc.edu', '2017-03-08', 'Gingival recession, severe', 9940, 3314, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('nlegrandb@mysql.com', '2011-08-02', 'Antimetabolic agents affecting fetus or newborn via placenta or breast milk',
   2339, 9921, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('abruyetc@microsoft.com', '2013-06-20', 'Mechanical complication due to breast prosthesis', 8382, 1936, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('chenninghamd@japanpost.jp', '2017-11-17',
        'Full-thickness skin loss [third degree,not otherwise specified] of breast', 5428, 2660, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kanthonsene@arstechnica.com', '2015-03-25', 'Other dermatitis due to solar radiation', 4526, 5546, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kgarrouldf@blogs.com', '2017-11-13', 'Polycystic kidney, autosomal dominant', 6166, 6897, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('echanceg@fastcompany.com', '2014-11-01', 'Laceration of cervix, postpartum condition or complication', 3954, 4268,
   'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('bcritchardh@altervista.org', '2012-10-13', 'Malignant neoplasm of liver, not specified as primary or secondary',
   1148, 5945, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('eyurygyni@lulu.com', '2017-09-14',
        'Thyrotoxicosis without mention of goiter or other cause, and without mention of thyrotoxic crisis or storm',
        2011, 7278, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kvelldenj@photobucket.com', '2010-06-28', 'Toxic myelitis', 9664, 6286, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('lmarcqk@smh.com.au', '2014-10-17', 'Unspecified osteomyelitis, hand', 2706, 2163, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('jfarransl@mlb.com', '2015-03-12',
        'Deep necrosis of underlying tissues [deep third degree] with loss of a body part, of lip(s)', 4393, 2788,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('mwooffm@china.com.cn', '2014-12-17', 'Accidents occurring in other specified places', 8485, 7409, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('hquadrin@home.pl', '2014-08-19',
        'Tuberculous bronchiectasis, tubercle bacilli not found by bacteriological examination, but tuberculosis confirmed histologically',
        9948, 8859, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('iwestcarro@princeton.edu', '2011-08-24',
        'Unspecified noninflammatory disorder of ovary, fallopian tube, and broad ligament', 7119, 5031, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('dlebbern0@cloudflare.com', '2013-01-06', 'Traumatic amputation of thumb (complete)(partial), complicated', 5669,
   2338, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('cvose1@livejournal.com', '2017-05-22', 'Fall from skis', 9336, 6497, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('yfaich2@usatoday.com', '2017-09-07', 'Arthropathy associated with other bacterial diseases, multiple sites', 5036,
   4673, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echiplen3@skyrock.com', '2014-12-22', 'Malignant neoplasm of scapula and long bones of upper limb', 8379, 2908,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('fkoeppe4@bbc.co.uk', '2010-08-12', 'Laparoscopic surgical procedure converted to open procedure', 8860, 5188,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('apoley5@tinypic.com', '2010-07-13', 'Cardiovascular disease, unspecified', 5159, 2576, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('ntuckerman6@about.com', '2012-02-18',
        'Thyrotoxicosis of other specified origin with mention of thyrotoxic crisis or storm', 5543, 2062, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('srames7@woothemes.com', '2017-04-25', 'Acquired absence of organ, eye', 7536, 9969, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bhammett8@nhs.uk', '2010-08-17',
        'Nonspecific (abnormal) findings on radiological and other examination of gastrointestinal tract', 9872, 1287,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('blifton9@weather.com', '2010-12-27',
        'Tuberculous abscess of spinal cord, tubercle bacilli not found by bacteriological examination, but tuberculosis confirmed histologically',
        2773, 5429, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('afugglesa@unc.edu', '2011-09-13', 'Intestinal infection due to enteroinvasive E. coli', 5007, 1347, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('nlegrandb@mysql.com', '2012-12-05', 'Pica', 1537, 1110, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('abruyetc@microsoft.com', '2016-12-24', 'Benign neoplasm of other specified sites', 2585, 3179, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('chenninghamd@japanpost.jp', '2011-10-30',
        'Personal history of (corrected) congenital malformations of eye, ear, face and neck', 5581, 4899, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kanthonsene@arstechnica.com', '2015-06-05', 'Convulsions in newborn', 6294, 1812, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kgarrouldf@blogs.com', '2015-08-29',
        'Motor vehicle traffic accident involving re-entrant collision with another motor vehicle injuring rider of animal; occupant of animal-drawn vehicle',
        4041, 4694, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echanceg@fastcompany.com', '2017-03-09', 'Schmorl''s nodes, lumbar region', 3733, 9453, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bcritchardh@altervista.org', '2013-12-08',
        'Better eye: severe vision impairment; lesser eye: blind, not further specified', 9179, 2630, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('eyurygyni@lulu.com', '2014-09-07', 'Neoplasm of uncertain behavior of pleura, thymus, and mediastinum', 8431, 4154,
   'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kvelldenj@photobucket.com', '2010-05-21',
        'Poisoning by corrosive and caustic substances, undetermined whether accidentally or purposely inflicted', 6702,
        8126, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('lmarcqk@smh.com.au', '2014-04-06', 'Unspecified deformity of ankle and foot, acquired', 2463, 9912, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('jfarransl@mlb.com', '2010-05-19',
        'Other motor vehicle nontraffic accident of other and unspecified nature injuring rider of animal; occupant of animal-drawn vehicle',
        7795, 4791, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('mwooffm@china.com.cn', '2011-05-21', 'Failure of sterile precautions during surgical operation', 8285, 2873,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('hquadrin@home.pl', '2013-02-22', 'Suicide and self-inflicted injury by firearms and explosives, unspecified', 4030,
   5070, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('iwestcarro@princeton.edu', '2010-12-03',
        'Other and unspecified water transport accident injuring occupant of other watercraft -- crew', 2953, 9002,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('iwestcarro@princeton.edu', '2013-01-06', 'Abrasion, unspecified', 8025, 5747, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('cvose1@livejournal.com', '2011-10-09', 'Open fracture of C1-C4 level with central cord syndrome', 2120, 5873,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('yfaich2@usatoday.com', '2011-02-19', 'Contusion of unspecified part of lower limb', 9816, 2950, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echiplen3@skyrock.com', '2015-05-09', 'Hypoxic-ischemic encephalopathy, unspecified', 3749, 1494, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('fkoeppe4@bbc.co.uk', '2016-01-20',
        'Other and unspecified cerebral laceration and contusion, without mention of open intracranial wound, with prolonged [more than 24 hours] loss of consciousness without return to pre-existing conscious level',
        1995, 8212, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('apoley5@tinypic.com', '2013-07-13', 'Blisters, epidermal loss [second degree] of trunk, unspecified site', 4749,
   3945, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('ntuckerman6@about.com', '2014-11-16', 'Personal history of allergy to sulfonamides', 2768, 6850, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('srames7@woothemes.com', '2017-11-16',
        'Failed medical or unspecified induction of labor, antepartum condition or complication', 3123, 6897, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bhammett8@nhs.uk', '2012-12-17', 'Acute pyelonephritis without lesion of renal medullary necrosis', 6087, 7258,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('blifton9@weather.com', '2010-10-05', 'Encephalomyelitis due to rubella', 8912, 3734, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('afugglesa@unc.edu', '2010-12-03', 'Hyperpotassemia', 9875, 2886, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('nlegrandb@mysql.com', '2014-09-10', 'Burn of unspecified degree of toe(s) (nail)', 2576, 8618, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('abruyetc@microsoft.com', '2012-04-17', 'Malignant neoplasm of transverse colon', 4600, 9444, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('chenninghamd@japanpost.jp', '2013-05-22', 'Other ill-defined cerebrovascular disease', 8592, 6189, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kanthonsene@arstechnica.com', '2015-04-01',
        'Abnormal glucose tolerance of mother, unspecified as to episode of care or not applicable', 4467, 6069,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kgarrouldf@blogs.com', '2014-10-17', 'Closed fracture of seventh cervical vertebra', 8219, 1786, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echanceg@fastcompany.com', '2010-12-02', 'Poisoning by oxazolidine derivatives', 3486, 5148, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bcritchardh@altervista.org', '2013-01-31', 'Nonspecific abnormal findings in saliva', 5166, 6976, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('eyurygyni@lulu.com', '2011-01-23', 'Closed dislocation of shoulder, unspecified', 7182, 7879, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kvelldenj@photobucket.com', '2013-02-22',
        'Other specified complications of pregnancy, antepartum condition or complication', 8132, 3830, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('lmarcqk@smh.com.au', '2011-11-14', 'Arthropathy associated with other bacterial diseases, shoulder region', 6048,
   7507, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('jfarransl@mlb.com', '2015-10-02', 'Acute poliomyelitis with other paralysis, poliovirus, unspecified type', 6423,
   2116, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('mwooffm@china.com.cn', '2016-06-30', 'Generalized infection during labor, antepartum condition or complication',
   1265, 9608, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('hquadrin@home.pl', '2018-04-08', 'Other sickle-cell disease without crisis', 6616, 5441, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('iwestcarro@princeton.edu', '2014-03-30', 'Mixed hearing loss, bilateral', 8713, 1140, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('dlebbern0@cloudflare.com', '2016-07-28', 'Sedative, hypnotic or anxiolytic dependence, unspecified', 2735, 5872,
   'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('cvose1@livejournal.com', '2014-08-23', 'Other symptoms involving digestive system', 3649, 2734, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('yfaich2@usatoday.com', '2011-09-10', 'Family history of blindness or visual loss', 4422, 3358, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echiplen3@skyrock.com', '2015-11-16',
        'Acute myocardial infarction of other lateral wall, subsequent episode of care', 4098, 3325, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('fkoeppe4@bbc.co.uk', '2016-04-20', 'Other specified disorders of urinary tract', 6733, 4313, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('apoley5@tinypic.com', '2016-07-15', 'Unspecified gastritis and gastroduodenitis, with hemorrhage', 8797, 7671,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('ntuckerman6@about.com', '2015-10-30', 'Claw hand (acquired)', 7906, 8990, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('srames7@woothemes.com', '2016-10-30',
        'Decreased fetal movements, affecting management of mother, unspecified as to episode of care', 3957, 8296,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bhammett8@nhs.uk', '2011-07-29', 'High grade myelodysplastic syndrome lesions', 6995, 8701, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('blifton9@weather.com', '2011-08-30', 'Unspecified disorder of the pituitary gland and its hypothalamic control',
   1872, 6983, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('afugglesa@unc.edu', '2015-01-04',
        'Bipolar I disorder, most recent episode (or current) mixed, severe, specified as with psychotic behavior',
        6376, 9909, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('nlegrandb@mysql.com', '2016-01-02', 'Insomnia with sleep apnea, unspecified', 9459, 2578, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('abruyetc@microsoft.com', '2015-04-12', 'Spina bifida without mention of hydrocephalus, lumbar region', 7670, 1589,
   'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('chenninghamd@japanpost.jp', '2013-08-09',
        'Poisoning by other carbon monoxide, undetermined whether accidentally or purposely inflicted', 5785, 1594,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kanthonsene@arstechnica.com', '2014-09-07',
        'Body Mass Index, pediatric, greater than or equal to 95th percentile for age', 4032, 2227, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kgarrouldf@blogs.com', '2011-08-03',
        'Poisoning by tranquilizers and other psychotropic agents, undetermined whether accidentally or purposely inflicted',
        4226, 9630, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echanceg@fastcompany.com', '2015-03-18',
        'Other specified obstetrical trauma, unspecified as to episode of care or not applicable', 3028, 9374, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('bcritchardh@altervista.org', '2015-09-26', 'Unspecified gingival and periodontal disease', 5495, 7650, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('eyurygyni@lulu.com', '2014-02-01', 'Aftercare following surgery of the genitourinary system, NEC', 4525, 4256,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kvelldenj@photobucket.com', '2017-08-13', 'Blisters, epidermal loss [second degree] of lower leg', 4566, 5949,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('lmarcqk@smh.com.au', '2013-04-12', 'Other fall', 9740, 9817, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('jfarransl@mlb.com', '2010-11-24', 'Bone replaced by transplant', 5697, 9258, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('mwooffm@china.com.cn', '2012-09-26', 'Obstructive hydrocephalus', 6179, 9208, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('hquadrin@home.pl', '2017-08-31', 'Accidental poisoning by sulfur dioxide', 6498, 6798, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('iwestcarro@princeton.edu', '2017-10-31', 'Beta thalassemia', 1001, 3256, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('dlebbern0@cloudflare.com', '2018-03-04', 'Leiomyoma of uterus, unspecified', 8798, 9563, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('cvose1@livejournal.com', '2012-02-12', 'Polyarticular juvenile rheumatoid arthritis, chronic or unspecified', 2732,
   8102, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('yfaich2@usatoday.com', '2010-10-09', 'Cystic fibrosis gene carrier', 3273, 6130, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echiplen3@skyrock.com', '2017-09-27',
        'Open fractures involving skull or face with other bones, with cerebral laceration and contusion, with brief [less than one hour] loss of consciousness',
        3571, 1891, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('fkoeppe4@bbc.co.uk', '2017-04-18', 'Major anomalies of jaw size, maxillary hypoplasia', 5724, 8060, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('apoley5@tinypic.com', '2011-05-18', 'Open fracture of intracapsular section of neck of femur, unspecified', 7076,
   6990, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('ntuckerman6@about.com', '2017-06-29', 'Sezary''s disease, lymph nodes of axilla and upper limb', 9841, 1603,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('srames7@woothemes.com', '2016-11-13',
        'Open wound of other and multiple sites of face, without mention of complication', 4377, 2086, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bhammett8@nhs.uk', '2014-11-03', 'Spasm of sphincter of Oddi', 6971, 1249, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('blifton9@weather.com', '2012-03-13', 'Other specified diseases of nail', 7079, 8140, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('afugglesa@unc.edu', '2017-11-02', 'Gonococcal conjunctivitis (neonatorum)', 3697, 9818, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('nlegrandb@mysql.com', '2015-09-08', 'Below knee amputation status', 5687, 4465, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('abruyetc@microsoft.com', '2013-11-24', 'Other specified disorders of prostate', 2912, 3101, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('chenninghamd@japanpost.jp', '2012-06-09',
        'Postpartum coagulation defects, delivered, with mention of postpartum complication', 7188, 5051, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kanthonsene@arstechnica.com', '2013-05-25', 'Open obturator dislocation of hip', 5277, 2913, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kgarrouldf@blogs.com', '2018-01-21', 'Arthropathy associated with mycoses, forearm', 9530, 5819, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echanceg@fastcompany.com', '2018-02-07', 'Other specified forms of effusion, except tuberculous', 3534, 6049,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bcritchardh@altervista.org', '2010-09-07', 'Late effect of superficial injury', 3980, 3125, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('eyurygyni@lulu.com', '2010-12-24', 'Talipes equinovarus', 1729, 6309, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kvelldenj@photobucket.com', '2017-12-24',
        'Closed fractures involving skull or face with other bones, with cerebral laceration and contusion, with prolonged [more than 24 hours] loss of consciousness and return to pre-existing conscious level',
        1286, 2058, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('lmarcqk@smh.com.au', '2015-04-18', 'Conjunctival pigmentations', 5229, 2276, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('jfarransl@mlb.com', '2011-12-22', 'Down''s syndrome', 2811, 1896, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('mwooffm@china.com.cn', '2014-06-19', 'Hemoperitoneum (nontraumatic)', 3462, 1236, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('hquadrin@home.pl', '2011-08-31',
        'Chronic or unspecified peptic ulcer of unspecified site with hemorrhage and perforation, without mention of obstruction',
        4071, 4123, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('iwestcarro@princeton.edu', '2014-09-25', 'Cardiac arrest', 4871, 7234, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('dlebbern0@cloudflare.com', '2017-07-30', 'Other disorders of coccyx', 2502, 6201, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('cvose1@livejournal.com', '2013-04-12',
        'Poisoning by keratolytics, keratoplastics, other hair treatment drugs and preparations', 4100, 5187, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('yfaich2@usatoday.com', '2016-10-08', 'Epistaxis', 4860, 4777, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('echiplen3@skyrock.com', '2012-04-13', 'Congenital abnormalities of uterus, postpartum condition or complication',
   3837, 3356, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('fkoeppe4@bbc.co.uk', '2013-04-16', 'Post traumatic seizures', 5499, 2290, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('apoley5@tinypic.com', '2010-08-27', 'Autistic disorder, current or active state', 9946, 2589, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('ntuckerman6@about.com', '2011-12-05', 'Unspecified disorder of optic nerve and visual pathways', 8778, 8032,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('srames7@woothemes.com', '2018-01-09', 'Fitting and adjustment of wheelchair', 5220, 8954, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bhammett8@nhs.uk', '2016-01-21', 'Pneumococcal peritonitis', 2233, 6165, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('blifton9@weather.com', '2010-08-20', 'Monocytosis (symptomatic)', 3898, 2076, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('afugglesa@unc.edu', '2012-04-01', 'Injury to sigmoid colon, with open wound into cavity', 3452, 5443, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('nlegrandb@mysql.com', '2011-11-02',
        'Cortex (cerebral) contusion without mention of open intracranial wound, with prolonged [more than 24 hours] loss of consciousness without return to pre-existing conscious level',
        2310, 5297, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('abruyetc@microsoft.com', '2011-08-09', 'Intraventricular hemorrhage, grade IV', 8426, 2322, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('chenninghamd@japanpost.jp', '2015-07-14', 'Abdominal pain, generalized', 6219, 2982, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kanthonsene@arstechnica.com', '2011-07-31', 'Arterial embolism and thrombosis of lower extremity', 6461, 5809,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kgarrouldf@blogs.com', '2011-10-09',
        'Papanicolaou smear of vagina with atypical squamous cells cannot exclude high grade squamous intraepithelial lesion (ASC-H)',
        8932, 9170, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echanceg@fastcompany.com', '2016-02-22', 'Closed fracture of condyle, femoral', 4385, 7918, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bcritchardh@altervista.org', '2013-10-18', 'Iatrogenic cerebrovascular infarction or hemorrhage', 2926, 3712,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('eyurygyni@lulu.com', '2012-07-10', 'Female orgasmic disorder', 3831, 4860, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('kvelldenj@photobucket.com', '2010-05-12', 'Injury due to war operations by gases, fumes, and chemicals', 6732, 6863,
   'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('lmarcqk@smh.com.au', '2014-04-09', 'Primary apnea of newborn', 7377, 4480, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('jfarransl@mlb.com', '2017-05-14', 'Toxic uninodular goiter with mention of thyrotoxic crisis or storm', 2518, 3630,
   'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('mwooffm@china.com.cn', '2011-09-06', 'Other interstitial and deep keratitis', 9329, 5033, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('hquadrin@home.pl', '2018-02-28', 'Accidental fall into storm drain or manhole', 5284, 8700, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('iwestcarro@princeton.edu', '2012-04-15', 'Closed dislocation, sacrum', 6813, 7113, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('dlebbern0@cloudflare.com', '2015-04-03', 'Arthropathy, unspecified, multiple sites', 8535, 2852, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('cvose1@livejournal.com', '2011-10-27', 'Open fracture of upper end of fibula alone', 7104, 6561, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('yfaich2@usatoday.com', '2016-04-23', 'Open lateral dislocation of elbow', 7403, 1931, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echiplen3@skyrock.com', '2017-09-19', 'Contusion of multiple sites of lower limb', 6606, 6986, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('fkoeppe4@bbc.co.uk', '2011-09-15',
        'Thyrotoxicosis from ectopic thyroid nodule without mention of thyrotoxic crisis or storm', 9999, 9770,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('apoley5@tinypic.com', '2014-05-17', 'Erythema [first degree] of eye (with other parts face, head, and neck)', 1532,
   3715, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('ntuckerman6@about.com', '2014-09-04', 'Full-thickness skin loss [third degree, not otherwise specified] of lip(s)',
   2040, 9560, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('srames7@woothemes.com', '2011-07-21', 'Poisoning by other psychostimulants', 6111, 1489, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bhammett8@nhs.uk', '2013-12-17', 'Familial Mediterranean fever', 6165, 9211, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('blifton9@weather.com', '2010-07-08', 'Mitral stenosis', 3908, 2971, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('afugglesa@unc.edu', '2014-09-26', 'Face or brow presentation, unspecified as to episode of care or not applicable',
   9910, 7397, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('nlegrandb@mysql.com', '2017-09-22',
        'Unspecified hypertension complicating pregnancy, childbirth, or the puerperium, antepartum condition or complication',
        7751, 6965, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('abruyetc@microsoft.com', '2018-02-17',
        'Other forms of migraine, with intractable migraine, so stated, without mention of status migrainosus', 2727,
        6797, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('chenninghamd@japanpost.jp', '2015-03-13',
        'Acute peptic ulcer of unspecified site with perforation, with obstruction', 1435, 2451, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kanthonsene@arstechnica.com', '2018-03-08', 'Colostomy and enterostomy complication, unspecified', 7602, 4415,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kgarrouldf@blogs.com', '2017-09-27',
        'Burn [any degree] involving 80-89 percent of body surface with third degree burn, 30-39%', 6002, 9372, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echanceg@fastcompany.com', '2011-07-19', 'Pneumonia in whooping cough', 4802, 5664, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bcritchardh@altervista.org', '2017-08-26', 'Supraglottitis unspecified, with obstruction', 4385, 5197, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('eyurygyni@lulu.com', '2013-06-02', 'Injury to dorsal nerve root', 6280, 7249, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kvelldenj@photobucket.com', '2016-09-19',
        'Deep necrosis of underlying tissues [deep third degree] with loss of a body part, of elbow', 2228, 2312,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('lmarcqk@smh.com.au', '2013-01-11', 'Chronic laryngotracheitis', 7600, 4664, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('jfarransl@mlb.com', '2018-01-02', 'Other fall', 1403, 3836, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('mwooffm@china.com.cn', '2015-12-15', 'Encounter for vocational therapy', 6772, 1430, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('hquadrin@home.pl', '2012-10-20',
        'Subdural hemorrhage following injury without mention of open intracranial wound, with moderate [1-24 hours] loss of consciousness',
        5884, 2669, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('iwestcarro@princeton.edu', '2013-04-27', 'Unspecified disorder of ear', 8875, 9155, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('dlebbern0@cloudflare.com', '2012-05-01', 'Other specified vaccinations against hemophilus influenza, type B [Hib]',
   4387, 6903, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('cvose1@livejournal.com', '2017-05-09',
        'Better eye: near-total vision impairment; lesser eye: total vision impairment', 4659, 1896, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('yfaich2@usatoday.com', '2011-10-23', 'Background retinopathy, unspecified', 1837, 1267, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echiplen3@skyrock.com', '2014-01-25', 'Listeriosis', 4104, 6589, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('fkoeppe4@bbc.co.uk', '2013-11-06',
        'Twin birth, unspecified whether mate liveborn or stillborn, born in hospital, delivered by cesarean section',
        9012, 6441, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('apoley5@tinypic.com', '2017-11-21', '"Light-for-dates" without mention of fetal malnutrition, 1,750- 1,999 grams',
   8075, 2603, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('ntuckerman6@about.com', '2016-01-05', 'Unspecified abortion, complicated by metabolic disorder, complete', 2885,
   8000, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('srames7@woothemes.com', '2015-09-19', 'Burn of unspecified degree of multiple sites of wrist(s) and hand(s)', 1638,
   4575, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bhammett8@nhs.uk', '2010-10-10', 'Hodgkin''s paragranuloma, lymph nodes of head, face, and neck', 4934, 5711,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('blifton9@weather.com', '2013-06-11', 'Tympanosclerosis, unspecified as to involvement', 3522, 7108, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('afugglesa@unc.edu', '2018-02-16',
        'Infections of genitourinary tract in pregnancy, postpartum condition or complication', 9324, 4298, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('nlegrandb@mysql.com', '2011-04-07',
        'Viral hepatitis B with hepatic coma, acute or unspecified, without mention of hepatitis delta', 4724, 7342,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('abruyetc@microsoft.com', '2011-07-19', 'Choroidal rupture', 2053, 1994, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('chenninghamd@japanpost.jp', '2012-06-13', 'Other open fracture of tarsal and metatarsal bones', 2295, 4188, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('kanthonsene@arstechnica.com', '2018-04-04', 'Insomnia due to medical condition classified elsewhere', 1580, 1777,
   'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kgarrouldf@blogs.com', '2011-06-09', 'Arthropathy, unspecified, shoulder region', 4649, 6534, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('echanceg@fastcompany.com', '2014-08-31', 'Chondrocalcinosis, due to pyrophosphate crystals, lower leg', 3831, 5388,
   'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bcritchardh@altervista.org', '2012-11-27', 'Urinary frequency', 2525, 4400, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('eyurygyni@lulu.com', '2012-10-11', 'Suspected problem with fetal growth not found', 8956, 1345, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('kvelldenj@photobucket.com', '2012-11-07', 'Cellulitis and abscess of hand, except fingers and thumb', 1675, 3822,
   'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('lmarcqk@smh.com.au', '2017-04-28', 'Gastrostomy status', 1276, 4574, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('jfarransl@mlb.com', '2015-12-17', 'Toxic effect of petroleum products', 2796, 5988, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('mwooffm@china.com.cn', '2012-02-10', 'Acute suppurative otitis media without spontaneous rupture of eardrum', 6799,
   3158, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('hquadrin@home.pl', '2012-06-08', 'Miliary tuberculosis, unspecified, unspecified', 5416, 1202, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('iwestcarro@princeton.edu', '2011-01-19',
        'Injury to liver without mention of open wound into cavity laceration, unspecified', 2420, 6403, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('dlebbern0@cloudflare.com', '2013-08-31', 'Organic insomnia, unspecified', 9640, 5751, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('cvose1@livejournal.com', '2015-10-31', 'Malignant neoplasm of other specified sites of oropharynx', 6627, 3207,
        'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('yfaich2@usatoday.com', '2015-08-12', 'Poisoning by other agents primarily affecting skin and mucous membrane', 5981,
   8711, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echiplen3@skyrock.com', '2017-10-17', 'Special screening for other malignant neoplasms', 6874, 8058, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('fkoeppe4@bbc.co.uk', '2017-03-21', 'Phlebitis and thrombophlebitis of femoral vein (deep) (superficial)', 8467,
        1546, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('apoley5@tinypic.com', '2016-03-03', 'Personal history of malignant neoplasm of tongue', 3189, 2529, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('ntuckerman6@about.com', '2012-09-20', 'Accidental poisoning by plant foods and fertilizers', 8778, 5025, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('srames7@woothemes.com', '2015-09-10',
        'Tuberculosis of other urinary organs, tubercle bacilli not found (in sputum) by microscopy, but found by bacterial culture',
        4369, 6958, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bhammett8@nhs.uk', '2012-07-21', 'Cervical rib', 3867, 5987, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('blifton9@weather.com', '2017-12-15', 'Polydactyly of fingers', 3852, 3934, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('afugglesa@unc.edu', '2018-04-17', 'Late effects of accident caused by fire', 1721, 2132, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('nlegrandb@mysql.com', '2017-06-09', 'Toxic shock syndrome', 4627, 4411, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('abruyetc@microsoft.com', '2012-06-26', 'Microcheilia', 6495, 8289, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('chenninghamd@japanpost.jp', '2015-07-23',
        'Injury due to other war operations but occurring after cessation of hostilities', 7580, 8837, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('kanthonsene@arstechnica.com', '2013-05-30', 'Poisoning by antimalarials and drugs acting on other blood protozoa',
   7805, 3096, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kgarrouldf@blogs.com', '2012-08-28', 'Other road vehicle accidents injuring unspecified person', 1862, 3239,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echanceg@fastcompany.com', '2010-12-01', 'Villonodular synovitis, upper arm', 9179, 2720, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bcritchardh@altervista.org', '2014-01-25', 'Routine infant or child health check', 2748, 3772, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('eyurygyni@lulu.com', '2017-11-28', 'Hemarthrosis, hand', 2595, 7782, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kvelldenj@photobucket.com', '2012-11-23', 'Neurogenic bladder NOS', 6563, 3000, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('lmarcqk@smh.com.au', '2016-10-14', 'Closed fracture of mandible, body, other and unspecified', 8185, 7015, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('jfarransl@mlb.com', '2012-12-12', 'Congenital cystic disease of liver', 1120, 4564, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('mwooffm@china.com.cn', '2017-05-06',
        'Calculus of bile duct without mention of cholecystitis, without mention of obstruction', 9223, 5733, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('hquadrin@home.pl', '2012-09-14', 'Systolic heart failure, unspecified', 2186, 8708, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('iwestcarro@princeton.edu', '2011-02-25', 'Mantle cell lymphoma, intra-abdominal lymph nodes', 8931, 1044, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('dlebbern0@cloudflare.com', '2013-02-08',
        'Persistent migraine aura without cerebral infarction, without mention of intractable migraine with status migrainosus',
        2326, 3532, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('cvose1@livejournal.com', '2017-01-13', 'Atheroembolism of lower extremity', 7097, 5971, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('yfaich2@usatoday.com', '2016-03-27', 'Closed dislocation of metacarpal (bone), proximal end', 8572, 9590, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echiplen3@skyrock.com', '2013-02-04', 'Rupture of papillary muscle', 4654, 8620, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('fkoeppe4@bbc.co.uk', '2017-07-23',
        'Other closed skull fracture without mention of intracranial injury, with prolonged [more than 24 hours] loss of consciousness and return to pre-existing conscious level',
        5581, 3154, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('apoley5@tinypic.com', '2014-03-13',
        'Other motor vehicle nontraffic accident involving collision with stationary object injuring unspecified person',
        6550, 2540, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('ntuckerman6@about.com', '2013-02-21', 'Familial Mediterranean fever', 8704, 6324, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('srames7@woothemes.com', '2017-10-29', 'Other disorders of papillary muscle', 2617, 3915, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bhammett8@nhs.uk', '2018-04-08', 'Atrophic gastritis, with hemorrhage', 5097, 1031, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('blifton9@weather.com', '2018-02-24',
        'Disruption of perineal wound, delivered, with mention of postpartum complication', 4112, 7463, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('afugglesa@unc.edu', '2012-09-07', 'Sarcosporidiosis', 4974, 2332, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('nlegrandb@mysql.com', '2018-04-11', 'Accidental poisoning by psychostimulants', 8627, 7286, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('abruyetc@microsoft.com', '2013-02-11', 'Retinal dystrophy in other systemic disorders and syndromes', 8819, 4787,
   'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('chenninghamd@japanpost.jp', '2017-05-28',
        'Chronic migraine without aura, with intractable migraine, so stated, without mention of status migrainosus',
        7536, 2358, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES
  ('kanthonsene@arstechnica.com', '2010-05-24', 'Injury due to war operations by other forms of conventional warfare',
   6317, 7056, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kgarrouldf@blogs.com', '2014-07-05', 'Pneumonia due to Pseudomonas', 6942, 1956, 'TRUE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('echanceg@fastcompany.com', '2011-12-23', 'Arthropathy, unspecified, site unspecified', 8265, 5521, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('bcritchardh@altervista.org', '2011-11-11', 'Proliferative diabetic retinopathy', 5013, 9268, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('eyurygyni@lulu.com', '2017-05-01',
        'Other complications due to other internal prosthetic device, implant, and graft', 8952, 3791, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('kvelldenj@photobucket.com', '2018-01-05', 'Other, mixed, or unspecified drug abuse, unspecified', 8417, 8257,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('lmarcqk@smh.com.au', '2018-03-19',
        'Cerebellar or brain stem contusion without mention of open intracranial wound, with moderate [1-24 hours] loss of consciousness',
        7072, 2973, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('jfarransl@mlb.com', '2010-10-31', 'Antidepressants causing adverse effects in therapeutic use', 1401, 6518,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('mwooffm@china.com.cn', '2016-12-17', 'Febrile nonhemolytic transfusion reaction', 2826, 6893, 'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('hquadrin@home.pl', '2011-12-26',
        'Late effects of cerebrovascular disease, other paralytic syndrome affecting nondominant side', 9781, 7590,
        'FALSE');
INSERT INTO laporan_keuangan (organisasi, tgl_dibuat, rincian_pemasukan, total_pemasukan, total_pengeluaran, is_disetujui)
VALUES ('iwestcarro@princeton.edu', '2014-11-30', 'Hodgkin''s disease, unspecified type, intrapelvic lymph nodes', 3295,
        7336, 'TRUE');
